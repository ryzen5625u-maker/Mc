# BlockHost Standalone — Android Studio source project

BlockHost Standalone manages a Minecraft **Java Edition** server directly from an Android app. It does not require Termux, a terminal app, root access, or a separate server-hosting app. The app owns the server and tunnel processes through its own foreground service and stores server files in Android app-private storage.

> **Important:** this is an Android Studio source project, not a prebuilt or device-tested APK. It still needs to be built in Android Studio and tested on a real ARM64 Android device. The current build environment did not have the Android SDK/Gradle dependencies available, so I could not truthfully claim a successful APK build.

## Standalone architecture

- **App-owned foreground service:** starts/stops the server, sends Minecraft console commands, reads logs, runs snapshots, and owns the optional Playit process.
- **No external terminal app:** the PRoot-compatible launcher is packaged in the APK's native-library directory and is SHA-256 checked again before use. The upstream runtime attribution/license notice is included in the APK assets and shown in the app's Access tab. On first run, the app downloads Canonical's Ubuntu Base ARM64 archive, verifies the official checksum list, extracts the Linux userspace into private app storage, then installs OpenJDK 21 using Ubuntu's package manager.
- **Local-first files:** the server JAR, `server.properties`, `eula.txt`, plugins, worlds, logs and snapshots are kept below the app's private `filesDir`. No broad storage permission is required.
- **Local-first snapshots:** while the server is running, the app asks Minecraft to flush saved data, temporarily pauses ordinary autosaving, archives the server files, validates the archive and keeps a small local history. Automatic snapshots are scheduled every 15 minutes when enabled.
- **Cloud backup:** a completed local snapshot is uploaded through Android's document-provider interface when a network is available. It is never used as a live world filesystem. Another device must restore a completed snapshot and only start after the old host is known to have stopped.
- **Background behavior:** a visible Android foreground-service notification and partial CPU wake lock are used while a server/tunnel process is active. Android/OEM power controls can still terminate or limit background processes; this is not a guaranteed 24/7 hosting service.

## Supported device and server

- Android 8.0 (API 26) or later.
- **64-bit ARM (`arm64-v8a`) only** in this iteration. x86/x86_64 and 32-bit ARM are not supported.
- Around **1.8 GB free storage is required for runtime setup**; reserve additional space for world data and several snapshots. The installed runtime may consume hundreds of megabytes.
- OpenJDK 21 is installed by the built-in runtime. Select a Minecraft server version compatible with Java 21. The app does not include or distribute a Minecraft server JAR; import a server JAR you are entitled to use.
- Plugins are intended for Paper/Spigot-compatible servers. Fabric/mod-loader server installation is not implemented in this iteration.

## Build the Android app

### Prerequisites

- Android Studio with Android SDK Platform 35 and build tools installed.
- JDK 17 for the Gradle build.
- Internet access to fetch the Gradle wrapper, Gradle distribution, Android/Kotlin dependencies and required runtime during first launch.

### Windows

1. Download and extract `BlockHostStandalone.zip` (the archive may still use the previous project name, while the in-app label is **BlockHost Standalone**).
2. In the extracted project folder, open PowerShell and run:

   ```powershell
   Set-ExecutionPolicy -Scope Process Bypass
   .\setup-wrapper.ps1
   ```

   The script downloads and SHA-256 verifies the Gradle 8.9 wrapper JAR **and** the five original PRoot launch/runtime assets. The PRoot files are placed under `app/src/main/jniLibs/arm64-v8a` so Android packages them into the APK's executable native-library directory. They are intentionally not included as binary files in the source ZIP.
3. Open the project root in Android Studio. Do not open only the `app` folder.
4. Let Gradle sync. If Android Studio asks for missing SDK components, install Android SDK Platform 35. Select the IDE-bundled JDK 17 under **Settings → Build, Execution, Deployment → Build Tools → Gradle**.
5. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. If the build succeeds, the debug APK is normally located at `app/build/outputs/apk/debug/app-debug.apk`.

### Linux/macOS

From the project root, run:

```sh
./setup-wrapper.sh
./gradlew assembleDebug
```

If the wrapper or dependencies cannot be downloaded, check the network connection and run the wrapper setup again. Do not use a wrapper JAR from an untrusted site.

## First run on the phone

1. Install the debug APK and open **BlockHost Standalone**.
2. Tap **Install built-in runtime** while connected to a reliable Wi-Fi network. Keep the app open during first setup; runtime downloads are several hundred megabytes and installation can take a while. The app validates the runtime files before using them.
3. Obtain a compatible Minecraft Java server JAR from its official project source and import it in the Server tab.
4. Read the Minecraft EULA at <https://aka.ms/MinecraftEULA>. Only check the EULA box if you accept it.
5. Configure RAM and server properties. Use modest view/simulation distance and memory settings on phones to avoid out-of-memory kills and overheating.
6. Start the server. Keep the app's foreground notification active and exclude the app from aggressive battery optimization when your phone offers that setting.
7. Test first from the same Wi-Fi network. For access from outside the network, import a compatible **Linux ARM64/glibc Playit agent** in the Playit section and follow the claim/status information shown in the BlockHost log. The agent is an executable run by BlockHost's embedded Linux runtime; no separate terminal app is used.

## Google Drive / cloud folder

The cloud tab uses Android's document-provider picker to select a folder (for example, a Google Drive folder exposed by a provider already configured on the device). It does **not** ask you to type or share a Google password. Share the folder with each collaborator's own account and select that same folder on the other device. Provider capabilities vary; verify that the selected provider supports persistent access and writing large files.

The app queues completed snapshots for upload when Android WorkManager is permitted to run with network access. WorkManager is opportunistic: sync may be delayed. A network interruption or device shutdown can delay cloud backup; local world data remains primary. The project does not treat Drive as a distributed lock or live filesystem.

## Important limits

- **No automatic host election/takeover.** If the old host loses internet, it may still be running and changing its local world. A second device must not start the same world until the first process is confirmed stopped.
- **Snapshots are not transactionally perfect copies of all plugin state.** The app asks the Minecraft server to flush world data before archiving, but third-party plugins may maintain external or asynchronous state. Test backups and restores with your specific plugins.
- **No remote ACL-controlled Start/Stop interface.** Folder sharing grants file access only; it does not grant permission to run console commands on another device. A secure coordination service and authenticated remote-control layer would be separate work.
- **Not zero data loss.** A crash can lose changes made since the last completed local snapshot. Keep multiple backups and test restoration before relying on it.
- The app's in-app access is limited to its private app directory. Uninstalling the app deletes its local data; make and verify cloud backups first.
- Google Play distribution of foreground-service use has additional policy declaration/review requirements. The manifest declares the `specialUse` foreground-service subtype for the user-requested Minecraft host.

## Runtime provenance

- PRoot-compatible runtime: <https://github.com/coderredlab/proroot> — the app obtains the upstream unmodified release assets and pins the expected SHA-256 values; it does not bundle or redistribute those binary assets in this source archive. The build includes the upstream license notice and shows runtime attribution in the Access tab; review the upstream terms before distributing your own build.
- Ubuntu Base ARM64: <https://cdimages.ubuntu.com/ubuntu-base/releases/24.04/release/> — the runtime checks Canonical's `SHA256SUMS` file before extracting the archive.
- Minecraft EULA: <https://aka.ms/MinecraftEULA>.
- Paper server requirements: <https://docs.papermc.io/paper/getting-started/>.

## Verification

Run `tools/verify-project.sh` for source-structure checks (manifest XML, required standalone classes, architecture/runtime pins, and absence of the obsolete external terminal command bridge). These checks are not a substitute for `assembleDebug`, a real-phone runtime installation, a test join from another device, a backup/restore test, and long-duration thermal/power testing.
