#!/usr/bin/env sh
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
DEST="$ROOT/gradle/wrapper/gradle-wrapper.jar"
URL="https://raw.githubusercontent.com/gradle/gradle/v8.9.0/gradle/wrapper/gradle-wrapper.jar"
EXPECTED="498495120a03b9a6ab5d155f5de3c8f0d986a449153702fb80fc80e134484f17"
ASSET_DIR="$ROOT/app/src/main/jniLibs/arm64-v8a"
PROOT_RELEASE="v1.2.8"
API="https://api.github.com/repos/coderredlab/proroot/releases/tags/$PROOT_RELEASE"

command -v curl >/dev/null 2>&1 || { echo "Install curl, then run this script again." >&2; exit 1; }
command -v python3 >/dev/null 2>&1 || { echo "Python 3 is required to safely read the upstream runtime asset metadata." >&2; exit 1; }
command -v sha256sum >/dev/null 2>&1 || command -v shasum >/dev/null 2>&1 || { echo "Install sha256sum or shasum to verify downloads." >&2; exit 1; }

hash_file() {
  if command -v sha256sum >/dev/null 2>&1; then sha256sum "$1" | awk '{print $1}'; else shasum -a 256 "$1" | awk '{print $1}'; fi
}

mkdir -p "$(dirname "$DEST")"
if [ ! -f "$DEST" ] || [ "$(hash_file "$DEST")" != "$EXPECTED" ]; then
  TMP="$DEST.tmp"
  rm -f "$TMP"
  curl --fail --location --retry 2 "$URL" -o "$TMP"
  ACTUAL="$(hash_file "$TMP")"
  if [ "$ACTUAL" != "$EXPECTED" ]; then rm -f "$TMP"; echo "Gradle wrapper checksum mismatch; refusing to install." >&2; exit 1; fi
  mv "$TMP" "$DEST"
fi
echo "Verified official Gradle 8.9 wrapper JAR."

mkdir -p "$ASSET_DIR"
RELEASE_JSON="$(mktemp)"
trap 'rm -f "$RELEASE_JSON"' EXIT HUP INT TERM
curl --fail --location --retry 2 -H 'Accept: application/vnd.github+json' -H 'User-Agent: BlockHost-Android' "$API" -o "$RELEASE_JSON"
python3 - "$RELEASE_JSON" "$PROOT_RELEASE" <<'PY'
import json, sys
with open(sys.argv[1], encoding='utf-8') as f: release = json.load(f)
if release.get('tag_name') != sys.argv[2]:
    raise SystemExit(f"Expected PRoot release {sys.argv[2]}, got {release.get('tag_name')!r}.")
PY

while IFS='|' read -r NAME EXPECTED; do
  [ -n "$NAME" ] || continue
  TARGET="$ASSET_DIR/$NAME"
  if [ -f "$TARGET" ] && [ "$(hash_file "$TARGET")" = "$EXPECTED" ]; then
    echo "Verified existing runtime asset $NAME"
    continue
  fi
  DOWNLOAD_URL="$(python3 - "$RELEASE_JSON" "$PROOT_RELEASE" "$NAME" <<'PY'
import json, sys
with open(sys.argv[1], encoding='utf-8') as f: release = json.load(f)
if release.get('tag_name') != sys.argv[2]: raise SystemExit('Release tag mismatch')
for asset in release.get('assets', []):
    if asset.get('name') == sys.argv[3]:
        print(asset['browser_download_url'])
        break
else:
    raise SystemExit(f"Asset not found in official release: {sys.argv[3]}")
PY
)"
  TMP="$TARGET.download"
  rm -f "$TMP"
  curl --fail --location --retry 2 "$DOWNLOAD_URL" -o "$TMP"
  ACTUAL="$(hash_file "$TMP")"
  if [ "$ACTUAL" != "$EXPECTED" ]; then rm -f "$TMP"; echo "SHA-256 mismatch for $NAME; refusing to package it." >&2; exit 1; fi
  mv "$TMP" "$TARGET"
  chmod 644 "$TARGET"
  echo "Downloaded and verified official runtime asset $NAME"
done <<'ASSETS'
libproroot.so|a4e74d75b66cdc02b080adfe863dbf9951c3b30610d77beddc95488d5fe5de01
libproroot-runtime.so|8c47a0a7db32d84c179ebb5bf3640f655a3181860ece5886ae44d92858730c34
libproroot-bridge.so|1c5bc9537a270e8bf8b1c70222813f57b60b828bfb5503ddf8fe37685092de2f
libproroot-linker.so|51a0ec5bfed00e572a0de09e22d9057e2befc386b78e426613d3e0ab03f4ecee
libproroot-stub-loader.so|06c6624db3bdc45b9ced151cd781df439a37b47731d244b93e9d6a58cd48cde2
ASSETS

echo "Native runtime assets are in app/src/main/jniLibs/arm64-v8a. Build the APK now; the resulting APK contains the standalone launcher."
