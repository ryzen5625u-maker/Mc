# Build a real APK using only your phone

This project is source code, not an APK. Use GitHub Actions to compile it on GitHub's cloud computer; no PC is needed.

## 1. Create a GitHub repository

1. In your phone browser, sign in at https://github.com/new.
2. Create a repository named `BlockHostStandalone`. A public repository is the simplest way to use GitHub Actions on the free plan. Do not add a README, license, or `.gitignore` at creation.
3. Open the new repository.

## 2. Upload the project ZIP

1. Choose **Add file → Upload files** and upload the original `BlockHostStandalone.zip` to the repository root. Commit it to `main`.
2. The ZIP contains the project folder. GitHub Actions needs the *extracted project files* at the repository root, so do not rely on uploading only the ZIP for the build workflow included in this source archive.

## 3. Recommended phone-only upload approach

Extract the ZIP on your phone first using the Files app or an archive utility. In GitHub's browser UI, use **Add file → Upload files** and upload the contents of the `BlockHostStandalone` directory, including the hidden `.github/workflows/build-apk.yml` file. If the mobile file picker cannot select folders or hidden files, switch the browser to **Desktop site** or use GitHub's web editor to create `.github/workflows/build-apk.yml` from the included workflow file.

Alternative if uploading all project files is too awkward: create the repository with the ZIP only, then use GitHub's **Code → Create codespace on main** (if available for your account), unzip the archive in the Codespace terminal, move the extracted project's contents to the repository root, commit, and push. Codespaces availability and free quotas vary.

## 4. Run the build

1. Open the repository's **Actions** tab.
2. Select **Build BlockHost APK**.
3. Tap **Run workflow**, choose `main`, and run it.
4. Wait for the workflow to finish green. If it fails, open the failed step and inspect the log; do not install an APK from a failed run.
5. Open the successful run, scroll to **Artifacts**, and download `BlockHostStandalone-debug-apk`.
6. Extract the artifact ZIP on your phone. It contains `app-debug.apk` and `SHA256SUMS.txt`.
7. Verify the APK's SHA-256 against the checksum file using a trusted checksum utility, then tap the APK to install. Android may ask you to allow installs from the browser or file manager you used.

## Trust and verification

A green workflow means Gradle completed and the APK file existed; it does not prove every feature works on your device. Inspect the workflow logs and source before installing. This is a debug APK, not a Play Store release. The APK is ARM64-only and is intended for compatible 64-bit ARM Android devices. The build downloads upstream runtime files and verifies their pinned SHA-256 hashes before packaging them.
