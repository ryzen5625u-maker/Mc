#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"

python3 - "$ROOT" <<'PY'
import pathlib, sys, xml.etree.ElementTree as ET
root = pathlib.Path(sys.argv[1])
manifest = root / "app/src/main/AndroidManifest.xml"
ET.parse(manifest)
text = manifest.read_text()
assert 'android:name=".StandaloneServerService"' in text, "standalone foreground service is missing"
assert 'android:foregroundServiceType="specialUse"' in text, "foreground service type is missing"
assert "RUN_COMMAND" not in text and "termux" not in text.lower(), "obsolete external terminal integration found in manifest"

main = root / "app/src/main/java/com/blockhost/app/MainActivity.kt"
controller = root / "app/src/main/java/com/blockhost/app/ServerController.kt"
runtime = root / "app/src/main/java/com/blockhost/app/RuntimeManager.kt"
service = root / "app/src/main/java/com/blockhost/app/StandaloneServerService.kt"
drive = root / "app/src/main/java/com/blockhost/app/DriveBackupStore.kt"
notices = root / "app/src/main/assets/THIRD_PARTY_NOTICES.txt"
for path in (main, controller, runtime, service, drive, notices):
    assert path.is_file() and path.stat().st_size > 1000, f"required source is missing or unexpectedly small: {path}"

rt = runtime.read_text()
assert 'arm64-v8a' in rt and 'runtime-ready' in rt and 'openjdk-21-jre-headless' in rt
assert 'SHA-256 verification failed' in rt and 'expectedToolHashes' in rt
assert 'termux' not in ''.join(p.read_text(errors='ignore').lower() for p in root.rglob('*') if p.is_file() and p.suffix in {'.kt', '.xml', '.kts'})
assert 'ContextCompat.startForegroundService' in controller.read_text()
assert 'WakeLock' in service.read_text() and 'createSnapshotArchive' in service.read_text()
assert 'DriveBackupWorker' in drive.read_text()
assert 'proroot' in notices.read_text().lower() and 'license notice' in notices.read_text().lower()
assert 'Embedded runtime attribution' in main.read_text()
assert 'PermissionPanel' not in main.read_text() and 'ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION' not in main.read_text()
assert (root / 'app/build.gradle.kts').is_file()
print('PASS: manifest XML; standalone service wiring; ARM64 runtime pins; checksum verification; local server, snapshot and Drive source presence.')
PY

if grep -RniE 'termux|RUN_COMMAND|control\.sh' "$ROOT/app/src/main"; then
  echo 'FAIL: obsolete external terminal integration remains in app source.' >&2
  exit 1
fi

echo 'PASS: no obsolete terminal command bridge or control.sh remains in app source.'
