$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Destination = Join-Path $Root 'gradle/wrapper/gradle-wrapper.jar'
$Temporary = "$Destination.tmp"
$Url = 'https://raw.githubusercontent.com/gradle/gradle/v8.9.0/gradle/wrapper/gradle-wrapper.jar'
$Expected = '498495120a03b9a6ab5d155f5de3c8f0d986a449153702fb80fc80e134484f17'
$AssetDir = Join-Path $Root 'app/src/main/jniLibs/arm64-v8a'
$ProrootRelease = 'v1.2.8'
$Api = "https://api.github.com/repos/coderredlab/proroot/releases/tags/$ProrootRelease"

New-Item -ItemType Directory -Force -Path (Split-Path -Parent $Destination) | Out-Null
if (!(Test-Path $Destination) -or (Get-FileHash -Path $Destination -Algorithm SHA256).Hash.ToLowerInvariant() -ne $Expected) {
    Invoke-WebRequest -Uri $Url -OutFile $Temporary
    $Actual = (Get-FileHash -Path $Temporary -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($Actual -ne $Expected) {
        Remove-Item $Temporary -Force -ErrorAction SilentlyContinue
        throw 'Checksum mismatch for Gradle wrapper JAR. Refusing to install it.'
    }
    Move-Item -Path $Temporary -Destination $Destination -Force
}
Write-Host 'Verified official Gradle 8.9 wrapper JAR.'

New-Item -ItemType Directory -Force -Path $AssetDir | Out-Null
$Headers = @{ 'Accept' = 'application/vnd.github+json'; 'User-Agent' = 'BlockHost-Android' }
$Release = Invoke-RestMethod -Uri $Api -Headers $Headers
if ($Release.tag_name -ne $ProrootRelease) { throw "Expected PRoot release $ProrootRelease, got $($Release.tag_name)." }
$ExpectedAssets = [ordered]@{
    'libproroot.so' = 'a4e74d75b66cdc02b080adfe863dbf9951c3b30610d77beddc95488d5fe5de01'
    'libproroot-runtime.so' = '8c47a0a7db32d84c179ebb5bf3640f655a3181860ece5886ae44d92858730c34'
    'libproroot-bridge.so' = '1c5bc9537a270e8bf8b1c70222813f57b60b828bfb5503ddf8fe37685092de2f'
    'libproroot-linker.so' = '51a0ec5bfed00e572a0de09e22d9057e2befc386b78e426613d3e0ab03f4ecee'
    'libproroot-stub-loader.so' = '06c6624db3bdc45b9ced151cd781df439a37b47731d244b93e9d6a58cd48cde2'
}
foreach ($Name in $ExpectedAssets.Keys) {
    $Target = Join-Path $AssetDir $Name
    $ExpectedHash = $ExpectedAssets[$Name]
    if ((Test-Path $Target) -and (Get-FileHash -Path $Target -Algorithm SHA256).Hash.ToLowerInvariant() -eq $ExpectedHash) {
        Write-Host "Verified existing runtime asset $Name"
        continue
    }
    $Asset = $Release.assets | Where-Object { $_.name -eq $Name } | Select-Object -First 1
    if ($null -eq $Asset) { throw "Asset $Name not found in the official PRoot release." }
    $TempAsset = "$Target.download"
    Remove-Item $TempAsset -Force -ErrorAction SilentlyContinue
    Invoke-WebRequest -Uri $Asset.browser_download_url -Headers @{ 'User-Agent' = 'BlockHost-Android' } -OutFile $TempAsset
    $ActualHash = (Get-FileHash -Path $TempAsset -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($ActualHash -ne $ExpectedHash) {
        Remove-Item $TempAsset -Force -ErrorAction SilentlyContinue
        throw "SHA-256 mismatch for $Name. Refusing to package it."
    }
    Move-Item -Path $TempAsset -Destination $Target -Force
    Write-Host "Downloaded and verified official runtime asset $Name"
}
Write-Host 'Native runtime assets are in app/src/main/jniLibs/arm64-v8a. Build the APK now; the resulting APK contains the standalone launcher.'
