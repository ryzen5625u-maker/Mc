plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.blockhost.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.blockhost.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "0.2.0-standalone"
    }

    buildFeatures { compose = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    packaging {
        // Executable PRoot assets must be physically extracted to nativeLibraryDir. This is
        // required on modern Android because files copied to writable filesDir cannot execve().
        jniLibs.useLegacyPackaging = true
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.12.01")
    implementation(composeBom)
    androidTestImplementation(composeBom)

    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    debugImplementation("androidx.compose.ui:ui-tooling")

    implementation("androidx.documentfile:documentfile:1.0.1")
    implementation("androidx.work:work-runtime-ktx:2.10.0")
    implementation("org.apache.commons:commons-compress:1.27.1")
}


// The archive contains no proprietary runtime binaries. Run setup-wrapper.ps1 / .sh before
// building; those scripts download the original upstream assets and verify their SHA-256 pins.
val pinnedProrootAssets = linkedMapOf(
    "libproroot.so" to "a4e74d75b66cdc02b080adfe863dbf9951c3b30610d77beddc95488d5fe5de01",
    "libproroot-runtime.so" to "8c47a0a7db32d84c179ebb5bf3640f655a3181860ece5886ae44d92858730c34",
    "libproroot-bridge.so" to "1c5bc9537a270e8bf8b1c70222813f57b60b828bfb5503ddf8fe37685092de2f",
    "libproroot-linker.so" to "51a0ec5bfed00e572a0de09e22d9057e2befc386b78e426613d3e0ab03f4ecee",
    "libproroot-stub-loader.so" to "06c6624db3bdc45b9ced151cd781df439a37b47731d244b93e9d6a58cd48cde2"
)
val verifyProrootAssets = tasks.register("verifyProrootNativeAssets") {
    group = "verification"
    description = "Verifies the upstream PRoot executables packaged into the Android APK."
    doLast {
        val assetDir = file("src/main/jniLibs/arm64-v8a")
        pinnedProrootAssets.forEach { (name, expected) ->
            val file = assetDir.resolve(name)
            if (!file.isFile) {
                throw GradleException("Missing embedded runtime asset $name. Run setup-wrapper.ps1 (Windows) or setup-wrapper.sh (Linux/macOS), then rebuild.")
            }
            val digest = java.security.MessageDigest.getInstance("SHA-256")
            file.inputStream().use { input ->
                val buffer = ByteArray(128 * 1024)
                while (true) {
                    val count = input.read(buffer)
                    if (count < 0) break
                    digest.update(buffer, 0, count)
                }
            }
            val actual = digest.digest().joinToString("") { "%02x".format(it.toInt() and 0xff) }
            if (!actual.equals(expected, ignoreCase = true)) {
                throw GradleException("SHA-256 mismatch for $name. Re-run setup-wrapper to fetch a verified upstream copy.")
            }
        }
    }
}
tasks.matching { it.name == "preBuild" }.configureEach { dependsOn(verifyProrootAssets) }
