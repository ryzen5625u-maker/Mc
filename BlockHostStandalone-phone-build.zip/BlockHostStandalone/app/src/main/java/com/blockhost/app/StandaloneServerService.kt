package com.blockhost.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.apache.commons.compress.archivers.tar.TarArchiveEntry
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.archivers.tar.TarArchiveOutputStream
import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream
import org.apache.commons.compress.compressors.gzip.GzipCompressorOutputStream
import org.apache.commons.compress.compressors.gzip.GzipParameters
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import java.util.zip.Deflater

/** The Minecraft server and optional Playit agent are child processes owned by this app. */
class StandaloneServerService : Service() {
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val actionMutex = Mutex()
    private val snapshotMutex = Mutex()
    private lateinit var controller: ServerController
    @Volatile private var serverProcess: Process? = null
    @Volatile private var playitProcess: Process? = null
    @Volatile private var stoppingNormally = false
    private var serverMonitor: Job? = null
    private var serverLogReader: Job? = null
    private var playitLogReader: Job? = null
    private var autoBackupJob: Job? = null
    private var cpuWakeLock: PowerManager.WakeLock? = null

    override fun onCreate() {
        super.onCreate()
        controller = ServerController(applicationContext)
        controller.ensureLayout()
        createNotificationChannel()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action != ACTION_REQUEST) return START_NOT_STICKY
        val operation = intent.getStringExtra(EXTRA_OPERATION) ?: return START_NOT_STICKY
        val requestId = intent.getStringExtra(EXTRA_REQUEST_ID).orEmpty()
        val args = intent.getStringArrayListExtra(EXTRA_ARGUMENTS)?.toList().orEmpty()
        startForeground(NOTIFICATION_ID, makeNotification("Working: $operation"))
        serviceScope.launch {
            val exitCode = try {
                actionMutex.withLock { execute(operation, args) }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Throwable) {
                controller.appendBridgeLog("$operation failed: ${error.message ?: error.javaClass.simpleName}")
                if (operation == "install-runtime") {
                    controller.getPreferences().edit()
                        .putString(ServerController.KEY_RUNTIME_STATUS, "ERROR")
                        .putString(ServerController.KEY_RUNTIME_PROGRESS, error.message ?: "Runtime installation failed")
                        .commit()
                }
                if (operation == "start") controller.writeStatus("ERROR")
                1
            }
            controller.writeControlResult(requestId, exitCode)
            refreshNotification()
            if (serverProcess?.isAlive != true && playitProcess?.isAlive != true) {
                // stopSelfResult protects later, already-queued actions from being lost.
                delay(400)
                if (serverProcess?.isAlive != true && playitProcess?.isAlive != true) {
                    if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE) else stopForeground(true)
                    stopSelfResult(startId)
                }
            }
        }
        return START_NOT_STICKY
    }

    private suspend fun execute(operation: String, args: List<String>): Int {
        when (operation) {
            "install-runtime" -> installRuntime()
            "start" -> startServer(args.firstOrNull()?.toIntOrNull() ?: controller.readSettings().memoryMb.toInt())
            "stop" -> stopServer()
            "status" -> refreshStatus()
            "cmd" -> sendConsoleCommand(args.firstOrNull().orEmpty())
            "backup" -> {
                val backup = createSnapshot()
                controller.appendBridgeLog("Snapshot ready: ${backup.name}")
            }
            "autobackup-start" -> startAutoBackups()
            "autobackup-stop" -> stopAutoBackups()
            "playit" -> startPlayit()
            "stop-playit" -> stopPlayit()
            "doctor" -> diagnostics()
            "restore" -> restoreBackup(args.firstOrNull()?.let(::File) ?: error("Choose a backup archive to restore."))
            else -> error("Unknown operation: $operation")
        }
        return 0
    }

    private suspend fun installRuntime() {
        check(serverProcess?.isAlive != true && playitProcess?.isAlive != true) {
            "Stop the Minecraft server and Playit tunnel before installing or repairing the runtime."
        }
        controller.writeStatus("INSTALLING")
        controller.getPreferences().edit().putString(ServerController.KEY_RUNTIME_STATUS, "INSTALLING").commit()
        RuntimeManager.install(this) { message ->
            controller.getPreferences().edit().putString(ServerController.KEY_RUNTIME_PROGRESS, message.take(400)).commit()
            controller.appendBridgeLog(message)
            refreshNotification(message.take(90))
        }
        controller.getPreferences().edit()
            .putString(ServerController.KEY_RUNTIME_STATUS, "READY")
            .putString(ServerController.KEY_RUNTIME_PROGRESS, "Ready — embedded Java 21 installed")
            .commit()
        if (serverProcess?.isAlive != true) controller.writeStatus("STOPPED")
        controller.appendBridgeLog("Embedded runtime setup finished successfully.")
    }

    private suspend fun startServer(heapMb: Int) {
        check(RuntimeManager.isInstalled(this)) { "Install the built-in Java runtime before starting the server." }
        check(controller.serverJarExists()) { "Import a compatible Minecraft Java server JAR first." }
        check(controller.eulaAccepted()) { "Read the Minecraft EULA and accept it in the Settings/Server panel first." }
        val current = serverProcess
        if (current?.isAlive == true) {
            controller.writeStatus("RUNNING")
            controller.appendBridgeLog("Server is already running.")
            return
        }
        val maxHeap = controller.recommendedMaxHeapMb()
        val heap = heapMb.coerceIn(512, maxHeap)
        val serverDir = controller.serverDir
        val command = listOf(
            "/usr/bin/java", "-Xms256M", "-Xmx${heap}M", "-jar", "server.jar", "nogui"
        )
        controller.writeStatus("STARTING")
        stoppingNormally = false
        rotateConsoleLog()
        val process = RuntimeManager.createProcess(
            this,
            command,
            binds = listOf(serverDir to "/server"),
            workingDirectory = "/server"
        )
        serverProcess = process
        updateWakeLock()
        serverLogReader = serviceScope.launch(Dispatchers.IO) {
            runCatching {
                process.inputStream.bufferedReader().useLines { lines ->
                    lines.forEach { line ->
                        controller.appendConsoleLog(line)
                        controller.appendBridgeLog("[server] $line")
                    }
                }
            }.onFailure { controller.appendBridgeLog("Console reader stopped: ${it.message}") }
        }
        serverMonitor = serviceScope.launch(Dispatchers.IO) {
            val exit = runCatching { process.waitFor() }.getOrDefault(-1)
            runCatching { serverLogReader?.join() }
            if (serverProcess === process) {
                serverProcess = null
                controller.writeStatus(if (stoppingNormally || exit == 0) "STOPPED" else "ERROR")
                controller.appendBridgeLog("Server process exited with code $exit.")
                autoBackupJob?.cancel()
                autoBackupJob = null
            }
            updateWakeLock()
            refreshNotification()
        }
        delay(1300)
        if (!process.isAlive) {
            runCatching { serverMonitor?.join() }
            error("Server exited during startup. Read the console log for the Java or server error.")
        }
        controller.writeStatus("RUNNING")
        controller.appendBridgeLog("Server process started with a ${heap} MiB Java heap.")
    }

    private suspend fun stopServer() {
        val process = serverProcess
        if (process == null || !process.isAlive) {
            controller.writeStatus("STOPPED")
            return
        }
        controller.writeStatus("STOPPING")
        stoppingNormally = true
        sendConsoleCommand("stop")
        val ended = withTimeoutOrNull(55_000L) {
            while (process.isAlive) delay(250)
            true
        } ?: false
        if (!ended) {
            stoppingNormally = false
            controller.writeStatus("RUNNING")
            error("The stop command was sent but the server is still saving. It was not force-killed; check console output and retry later.")
        }
        controller.writeStatus("STOPPED")
        autoBackupJob?.cancel()
        autoBackupJob = null
        controller.appendBridgeLog("Server stopped.")
    }

    private suspend fun sendConsoleCommand(command: String) {
        require(command.isNotBlank()) { "Command is empty." }
        require(!command.contains('\n') && !command.contains('\r')) { "Send only one Minecraft console command at a time." }
        val process = serverProcess?.takeIf { it.isAlive }
            ?: error("The Minecraft server is not running.")
        process.outputStream.write((command.trim() + "\n").toByteArray(Charsets.UTF_8))
        process.outputStream.flush()
        controller.appendBridgeLog("Console command sent: ${command.trim().take(160)}")
    }

    private suspend fun refreshStatus() {
        val active = serverProcess?.isAlive == true
        if (active) controller.writeStatus(if (controller.readStatus() == "STOPPING") "STOPPING" else "RUNNING")
        else if (controller.readStatus() !in setOf("INSTALLING", "READY")) controller.writeStatus("STOPPED")
        controller.appendBridgeLog("Status checked: ${controller.readStatus()}; runtime=${if (RuntimeManager.isInstalled(this)) "ready" else "not installed"}.")
    }

    private suspend fun createSnapshot(): File = snapshotMutex.withLock {
        controller.ensureLayout()
        check(controller.serverDir.isDirectory) { "Server directory is missing." }
        val activeProcess = serverProcess?.takeIf { it.isAlive }
        var paused = false
        try {
            if (activeProcess != null) {
                val beforeSaveOff = controller.consoleLog.length()
                sendConsoleCommand("save-off")
                check(waitForConsole(afterBytes = beforeSaveOff, timeoutMs = 15_000L) {
                    it.contains("automatic saving is now disabled", ignoreCase = true)
                }) { "The server did not confirm save-off. Snapshot aborted." }
                paused = true
                val beforeSaveAll = controller.consoleLog.length()
                sendConsoleCommand("save-all flush")
                check(waitForConsole(afterBytes = beforeSaveAll, timeoutMs = 45_000L) {
                    it.contains("saved the game", ignoreCase = true) || it.contains("saved the world", ignoreCase = true)
                }) { "The server did not confirm save-all flush. Snapshot aborted to avoid an unreliable archive." }
            }
            createSnapshotArchive()
        } finally {
            if (paused && serverProcess?.isAlive == true) {
                runCatching { sendConsoleCommand("save-on") }
                controller.appendBridgeLog("Autosave re-enabled after snapshot attempt.")
            }
        }
    }

    private suspend fun waitForConsole(afterBytes: Long, timeoutMs: Long, predicate: (String) -> Boolean): Boolean {
        return withTimeoutOrNull(timeoutMs) {
            while (true) {
                if (serverProcess?.isAlive != true) return@withTimeoutOrNull false
                val file = controller.consoleLog
                if (file.isFile && file.length() > afterBytes) {
                    val text = runCatching {
                        java.io.RandomAccessFile(file, "r").use { input ->
                            input.seek(afterBytes.coerceAtMost(input.length()))
                            val bytes = ByteArray((input.length() - input.filePointer).coerceAtMost(256 * 1024L).toInt())
                            input.readFully(bytes)
                            String(bytes, Charsets.UTF_8)
                        }
                    }.getOrDefault("")
                    if (predicate(text)) return@withTimeoutOrNull true
                }
                delay(250)
            }
            @Suppress("UNREACHABLE_CODE") false
        } ?: false
    }

    private fun createSnapshotArchive(): File {
        val source = controller.serverDir
        val backupDir = controller.backupsDir
        check(backupDir.mkdirs() || backupDir.isDirectory)
        val sourceBytes = source.walkTopDown().filter { it.isFile && !Files.isSymbolicLink(it.toPath()) }
            .sumOf { it.length() }
        val available = backupDir.usableSpace
        check(available >= sourceBytes + 256L * 1024L * 1024L) {
            "Not enough free device storage for a safe snapshot; keep at least the server directory size plus 256 MiB free."
        }
        val stamp = SimpleDateFormat("yyyyMMdd'T'HHmmss'Z'", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }.format(Date())
        val staged = File(backupDir, ".BlockHost-$stamp.tar.gz.tmp")
        return try {
            FileOutputStream(staged).use { fileOut ->
                val params = GzipParameters().apply { compressionLevel = Deflater.BEST_SPEED }
                TarArchiveOutputStream(GzipCompressorOutputStream(BufferedOutputStream(fileOut), params)).use { tar ->
                    tar.setLongFileMode(TarArchiveOutputStream.LONGFILE_POSIX)
                    tar.setBigNumberMode(TarArchiveOutputStream.BIGNUMBER_POSIX)
                    source.walkTopDown().forEach { file ->
                        if (Files.isSymbolicLink(file.toPath())) return@forEach
                        val relative = file.relativeTo(source).invariantSeparatorsPath
                        if (relative.isBlank()) return@forEach
                        val first = relative.substringBefore('/')
                        if (first in setOf("logs", "cache", "crash-reports")) return@forEach
                        if (file.isDirectory) {
                            val entry = TarArchiveEntry(file, "$relative/")
                            tar.putArchiveEntry(entry)
                            tar.closeArchiveEntry()
                        } else if (file.isFile) {
                            val entry = TarArchiveEntry(file, relative)
                            tar.putArchiveEntry(entry)
                            FileInputStream(file).use { input -> input.copyTo(tar, 128 * 1024) }
                            tar.closeArchiveEntry()
                        }
                    }
                    tar.finish()
                }
            }
            FileOutputStream(staged, true).use { it.fd.sync() }
            validateBackupArchive(staged)
            val digest = sha256(staged)
            val finalFile = File(backupDir, "BlockHost-$stamp-${digest.take(12)}.tar.gz")
            moveReplace(staged, finalFile)
            File(controller.baseDir, "latest_backup.txt").writeText(finalFile.absolutePath + "\n")
            controller.localBackups().drop(8).forEach { it.delete() }
            finalFile
        } finally { staged.delete() }
    }

    private fun validateBackupArchive(file: File) {
        var hasServerJar = false
        TarArchiveInputStream(GzipCompressorInputStream(BufferedInputStream(FileInputStream(file)))).use { tar ->
            var entry: TarArchiveEntry? = tar.nextTarEntry
            val buffer = ByteArray(64 * 1024)
            while (entry != null) {
                val name = entry.name.replace('\\', '/')
                val path = java.nio.file.Paths.get(name).normalize()
                require(!path.isAbsolute && path.toString() != ".." && !path.startsWith("..") && !name.startsWith("/")) {
                    "Archive contains an unsafe path; snapshot rejected."
                }
                require(!entry.isSymbolicLink && !entry.isLink && !entry.isBlockDevice && !entry.isCharacterDevice && !entry.isFIFO) {
                    "Archive contains a link or special file; snapshot rejected."
                }
                if (name == "server.jar") hasServerJar = true
                while (tar.read(buffer) >= 0) { /* force GZIP CRC verification */ }
                entry = tar.nextTarEntry
            }
        }
        check(hasServerJar) { "Snapshot is missing server.jar." }
    }

    private suspend fun restoreBackup(archive: File) = withContext(Dispatchers.IO) {
        check(serverProcess?.isAlive != true) { "Stop the server before restoring a snapshot." }
        val backupRoot = controller.backupsDir.canonicalFile
        check(archive.isFile && archive.canonicalFile.parentFile == backupRoot && archive.name.startsWith("BlockHost-") && archive.name.endsWith(".tar.gz")) {
            "Restore only accepts a completed local BlockHost snapshot. Download the Drive snapshot first."
        }
        validateBackupArchive(archive)
        val stage = File(controller.baseDir, ".restore-stage-${UUID.randomUUID()}")
        check(stage.mkdirs()) { "Could not create a staging directory for restore." }
        try {
            TarArchiveInputStream(GzipCompressorInputStream(BufferedInputStream(FileInputStream(archive)))).use { tar ->
                var entry: TarArchiveEntry? = tar.nextTarEntry
                val buffer = ByteArray(64 * 1024)
                val stagePath = stage.toPath().toAbsolutePath().normalize()
                while (entry != null) {
                    val name = entry.name.replace('\\', '/')
                    val relative = java.nio.file.Paths.get(name).normalize()
                    require(!relative.isAbsolute && relative.toString() != ".." && !relative.startsWith("..") && !name.startsWith("/")) {
                        "Snapshot contains an unsafe path."
                    }
                    require(!entry.isSymbolicLink && !entry.isLink && !entry.isBlockDevice && !entry.isCharacterDevice && !entry.isFIFO) {
                        "Snapshot contains a link or special file."
                    }
                    val target = stagePath.resolve(relative).normalize()
                    require(target.startsWith(stagePath)) { "Snapshot path escapes the restore directory." }
                    when {
                        entry.isDirectory -> Files.createDirectories(target)
                        entry.isFile -> {
                            Files.createDirectories(target.parent)
                            FileOutputStream(target.toFile()).use { output ->
                                while (true) {
                                    val count = tar.read(buffer)
                                    if (count < 0) break
                                    output.write(buffer, 0, count)
                                }
                                output.fd.sync()
                            }
                        }
                    }
                    entry = tar.nextTarEntry
                }
            }
            check(File(stage, "server.jar").isFile) { "Snapshot did not contain server.jar." }
            val previous = File(controller.baseDir, "server-before-restore-${System.currentTimeMillis()}")
            if (controller.serverDir.exists()) moveReplace(controller.serverDir, previous)
            try {
                moveReplace(stage, controller.serverDir)
            } catch (error: Exception) {
                if (previous.exists() && !controller.serverDir.exists()) moveReplace(previous, controller.serverDir)
                throw error
            }
            controller.ensureLayout()
            controller.appendBridgeLog("Restored snapshot ${archive.name}. Previous server files retained at ${previous.name}.")
        } finally { stage.deleteRecursively() }
    }

    private fun startAutoBackups() {
        controller.getPreferences().edit().putBoolean(ServerController.KEY_AUTO_BACKUP, true).commit()
        if (autoBackupJob?.isActive == true) return
        autoBackupJob = serviceScope.launch {
            while (isActive) {
                delay(15 * 60 * 1000L)
                if (serverProcess?.isAlive == true) {
                    runCatching { createSnapshot() }
                        .onSuccess { controller.appendBridgeLog("Scheduled snapshot completed: ${it.name}") }
                        .onFailure { controller.appendBridgeLog("Scheduled snapshot skipped/failed: ${it.message}") }
                }
            }
        }
        controller.appendBridgeLog("Local 15-minute snapshot loop enabled.")
    }

    private fun stopAutoBackups() {
        controller.getPreferences().edit().putBoolean(ServerController.KEY_AUTO_BACKUP, false).commit()
        autoBackupJob?.cancel()
        autoBackupJob = null
        controller.appendBridgeLog("Automatic snapshots disabled.")
    }

    private fun startPlayit() {
        check(RuntimeManager.isInstalled(this)) { "Install the built-in runtime before starting Playit." }
        if (playitProcess?.isAlive == true) return
        val binary = File(controller.baseDir, "bin/playit")
        check(binary.isFile && binary.length() > 0L) { "Import a Linux ARM64 Playit agent from the Playit project first." }
        check(binary.canExecute()) { "Playit agent is not executable." }
        val process = RuntimeManager.createProcess(
            this,
            listOf("/hostbin/playit"),
            binds = listOf(File(controller.baseDir, "bin") to "/hostbin"),
            workingDirectory = "/root"
        )
        playitProcess = process
        updateWakeLock()
        playitLogReader = serviceScope.launch(Dispatchers.IO) {
            runCatching {
                process.inputStream.bufferedReader().useLines { lines ->
                    lines.forEach { line -> controller.appendBridgeLog("[playit] $line") }
                }
            }
        }
        serviceScope.launch {
            val code = withContext(Dispatchers.IO) { runCatching { process.waitFor() }.getOrDefault(-1) }
            if (playitProcess === process) playitProcess = null
            controller.appendBridgeLog("Playit process exited with code $code.")
            updateWakeLock()
            refreshNotification()
        }
        controller.appendBridgeLog("Playit agent started in the embedded Linux runtime. Check recent log output for its claim URL/status.")
    }

    private fun stopPlayit() {
        val process = playitProcess ?: return
        if (process.isAlive) process.destroy()
        playitProcess = null
        updateWakeLock()
        controller.appendBridgeLog("Stop requested for Playit agent.")
    }

    private suspend fun diagnostics() {
        controller.appendBridgeLog("Diagnostics: Android ABI=${Build.SUPPORTED_ABIS.joinToString()}; runtime=${RuntimeManager.isInstalled(this)}; availableStorage=${controller.baseDir.usableSpace / (1024 * 1024)} MiB; jar=${controller.serverJarExists()}; eula=${controller.eulaAccepted()}; server=${controller.readStatus()}; playit=${File(controller.baseDir, "bin/playit").isFile}.")
        if (RuntimeManager.isInstalled(this)) {
            val exit = RuntimeManager.runGuestCommand(this, listOf("/usr/bin/java", "-version")) { line -> controller.appendBridgeLog("[java] $line") }
            check(exit == 0) { "The built-in Java runtime failed its version check." }
        } else {
            controller.appendBridgeLog("Tap Install built-in runtime before starting the server.")
        }
    }

    private fun rotateConsoleLog() {
        val file = controller.consoleLog
        if (file.isFile && file.length() > 10L * 1024L * 1024L) {
            val old = File(file.parentFile, "console.log.1")
            old.delete()
            moveReplace(file, old)
        }
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { input ->
            val buffer = ByteArray(128 * 1024)
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                digest.update(buffer, 0, count)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(Locale.ROOT, it.toInt() and 0xff) }
    }

    private fun moveReplace(from: File, to: File) {
        try { Files.move(from.toPath(), to.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE) }
        catch (_: Exception) { Files.move(from.toPath(), to.toPath(), StandardCopyOption.REPLACE_EXISTING) }
    }

    /** A user-started server needs CPU time with the screen off. The lock is released as soon as
     * both long-running child processes exit; it does not guarantee uninterrupted Android uptime. */
    private fun updateWakeLock() {
        val shouldHold = serverProcess?.isAlive == true || playitProcess?.isAlive == true
        if (shouldHold) {
            if (cpuWakeLock?.isHeld != true) {
                val manager = getSystemService(Context.POWER_SERVICE) as PowerManager
                cpuWakeLock = manager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "$packageName:BlockHostServer").apply {
                    setReferenceCounted(false)
                    acquire()
                }
            }
        } else {
            runCatching { cpuWakeLock?.takeIf { it.isHeld }?.release() }
            cpuWakeLock = null
        }
    }

    private fun refreshNotification(customText: String? = null) {
        val text = customText ?: when {
            serverProcess?.isAlive == true && playitProcess?.isAlive == true -> "Minecraft server and Playit are running"
            serverProcess?.isAlive == true -> "Minecraft server is running"
            playitProcess?.isAlive == true -> "Playit tunnel agent is running"
            controller.runtimeReady() -> "Built-in runtime ready"
            else -> controller.runtimeProgress().take(90)
        }
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIFICATION_ID, makeNotification(text))
    }

    private fun makeNotification(text: String): Notification {
        val openApp = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle("BlockHost")
            .setContentText(text)
            .setContentIntent(openApp)
            .setOngoing(serverProcess?.isAlive == true || playitProcess?.isAlive == true || !RuntimeManager.isInstalled(this))
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_ID, "BlockHost server", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Shows server state and runtime installation progress."
                setShowBadge(false)
            }
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        autoBackupJob?.cancel()
        runCatching { cpuWakeLock?.takeIf { it.isHeld }?.release() }
        cpuWakeLock = null
        serviceScope.cancel()
        super.onDestroy()
    }

    companion object {
        const val ACTION_REQUEST = "com.blockhost.app.SERVER_REQUEST"
        const val EXTRA_OPERATION = "operation"
        const val EXTRA_REQUEST_ID = "request_id"
        const val EXTRA_ARGUMENTS = "arguments"
        private const val CHANNEL_ID = "blockhost_server"
        private const val NOTIFICATION_ID = 4701
    }
}

