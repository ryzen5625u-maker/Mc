package com.blockhost.app

import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        schedulePeriodicDriveSync(this)
        setContent { MaterialTheme { BlockHostApp() } }
    }
}

private enum class AppTab(val title: String) {
    SERVER("Server"), PLUGINS("Plugins"), SETTINGS("Settings"), DRIVE("Drive"), ACCESS("Access")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun BlockHostApp() {
    val context = LocalContext.current
    val controller = remember { ServerController(context.applicationContext) }
    val scope = rememberCoroutineScope()
    var selectedTab by rememberSaveable { mutableStateOf(AppTab.SERVER) }
    var refreshKey by rememberSaveable { mutableStateOf(0) }
    var serverStatus by rememberSaveable { mutableStateOf("STOPPED") }
    var recentLog by rememberSaveable { mutableStateOf("No control output yet.") }
    var busy by rememberSaveable { mutableStateOf(false) }

    fun toast(message: String) = Toast.makeText(context, message, Toast.LENGTH_LONG).show()
    fun refreshStatus() {
        scope.launch {
            try {
                val requestId = withContext(Dispatchers.IO) { controller.runControl("status") }
                awaitControlResult(controller, requestId, 10_000L)
                serverStatus = withContext(Dispatchers.IO) { controller.readStatus() }
                recentLog = withContext(Dispatchers.IO) { controller.recentBridgeLog() }
                refreshKey++
            } catch (e: Exception) {
                recentLog = e.message ?: "Could not communicate with BlockHost's embedded runtime."
                toast("BlockHost status check failed: ${e.message ?: "unknown error"}")
            }
        }
    }

    fun runTask(successMessage: String, block: suspend () -> Unit) {
        if (busy) return
        busy = true
        scope.launch {
            try {
                withContext(Dispatchers.IO) { block() }
                toast(successMessage)
                refreshKey++
                try {
                    val requestId = withContext(Dispatchers.IO) { controller.runControl("status") }
                    awaitControlResult(controller, requestId, 10_000L)
                    serverStatus = withContext(Dispatchers.IO) { controller.readStatus() }
                    recentLog = withContext(Dispatchers.IO) { controller.recentBridgeLog() }
                } catch (_: Exception) { }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                toast(error.message ?: "Action failed")
            } finally {
                busy = false
            }
        }
    }

    val jarPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) runTask("Server JAR imported.") { controller.importServerJar(uri) }
    }
    val pluginPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val name = queryDisplayName(context.contentResolver, uri)
            runTask("Plugin imported.") { controller.importPlugin(uri, name) }
        }
    }
    val playitPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) runTask("Playit agent imported into BlockHost private storage.") { controller.importPlayitBinary(uri) }
    }
    val driveFolderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            runCatching { DriveBackupStore.saveFolder(context, uri) }
                .onSuccess {
                    scheduleImmediateDriveSync(context)
                    toast("Cloud folder connected. Share this same folder with other users from Drive.")
                    refreshKey++
                }
                .onFailure { toast("Could not connect folder: ${it.message}") }
        }
    }

    LaunchedEffect(Unit) { refreshStatus() }
    LaunchedEffect(busy) {
        // Runtime downloads and package installation can take several minutes. Refresh the card
        // text while an operation is active so the user sees install progress instead of a frozen UI.
        while (busy) {
            delay(1000)
            refreshKey++
        }
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("BlockHost Standalone", fontWeight = FontWeight.Bold) }) },
        bottomBar = {
            NavigationBar {
                AppTab.entries.forEach { tab ->
                    NavigationBarItem(
                        selected = selectedTab == tab,
                        onClick = { selectedTab = tab },
                        icon = { Text(tab.title.take(1)) },
                        label = { Text(tab.title) }
                    )
                }
            }
        }
    ) { innerPadding ->
        when (selectedTab) {
                AppTab.SERVER -> ServerPanel(
                    modifier = Modifier.padding(innerPadding), controller = controller,
                    status = serverStatus, logText = recentLog, busy = busy,
                    refreshKey = refreshKey,
                    onInitializeRuntime = {
                        runTask("Built-in Linux and Java runtime installed.") {
                            val installId = controller.runControl("install-runtime")
                            awaitControlResult(controller, installId, 1_800_000L)
                        }
                    },
                    onStart = {
                        runTask("Server process started. Check the console for startup completion.") {
                            check(controller.runtimeReady()) { "Install the built-in Linux/Java runtime first." }
                            check(controller.serverJarExists()) { "Import a Paper or compatible server JAR first." }
                            check(controller.eulaAccepted()) { "Read the Minecraft EULA and accept it in the checkbox below first." }
                            val settings = controller.readSettings()
                            val startId = controller.runControl("start", settings.memoryMb.toIntOrNull()?.coerceIn(512, controller.recommendedMaxHeapMb())?.toString() ?: "1536")
                            awaitControlResult(controller, startId, 20_000L)
                            val prefs = context.getSharedPreferences(ServerController.PREFS, android.content.Context.MODE_PRIVATE)
                            if (prefs.getBoolean(ServerController.KEY_AUTO_BACKUP, true)) {
                                val backupLoopId = controller.runControl("autobackup-start")
                                awaitControlResult(controller, backupLoopId, 10_000L)
                            }
                        }
                    },
                    onStop = { runTask("Server stopped cleanly.") { awaitControlResult(controller, controller.runControl("stop"), 50_000L) } },
                    onRefresh = ::refreshStatus,
                    onDiagnose = { runTask("Diagnostics complete; see Recent control log.") { awaitControlResult(controller, controller.runControl("doctor"), 15_000L) } },
                    onImportJar = { jarPicker.launch(arrayOf("*/*")) },
                    onLaunchPlayit = { runTask("Playit launch request completed; confirm the tunnel is online.") { awaitControlResult(controller, controller.runControl("playit"), 15_000L) } },
                    onStopPlayit = { runTask("Playit stop request sent.") { awaitControlResult(controller, controller.runControl("stop-playit"), 10_000L) } },
                    onImportPlayit = { playitPicker.launch(arrayOf("*/*")) },
                    onBackup = {
                        runTask("Snapshot finished and cloud sync queued.") {
                            createSnapshotAndQueueSync(context, controller)
                        }
                    },
                    onAutoBackup = {
                        val prefs = context.getSharedPreferences(ServerController.PREFS, android.content.Context.MODE_PRIVATE)
                        val enable = !(prefs.getBoolean(ServerController.KEY_AUTO_BACKUP, true))
                        runTask(if (enable) "Automatic local snapshots enabled." else "Automatic local snapshots disabled.") {
                            if (!enable) {
                                // Persist the user's intent before waiting for an in-flight snapshot to finish.
                                check(prefs.edit().putBoolean(ServerController.KEY_AUTO_BACKUP, false).commit())
                            }
                            val requestId = controller.runControl(if (enable) "autobackup-start" else "autobackup-stop")
                            awaitControlResult(controller, requestId, 200_000L)
                            if (enable) check(prefs.edit().putBoolean(ServerController.KEY_AUTO_BACKUP, true).commit())
                        }
                    },
                    onEula = { checked ->
                        runTask(if (checked) "EULA acceptance saved." else "EULA set to not accepted.") {
                            controller.setEulaAccepted(checked)
                        }
                    },
                    onConsole = { command -> runTask("Console command sent.") { awaitControlResult(controller, controller.runControl("cmd", command), 10_000L) } }
                )
                AppTab.PLUGINS -> PluginPanel(
                    modifier = Modifier.padding(innerPadding), controller = controller,
                    refreshKey = refreshKey, serverStopped = serverStatus == "STOPPED",
                    onImport = { pluginPicker.launch(arrayOf("*/*")) },
                    onDelete = { fileName -> runTask("Plugin removed.") { controller.deletePlugin(fileName) } }
                )
                AppTab.SETTINGS -> SettingsPanel(
                    modifier = Modifier.padding(innerPadding), controller = controller,
                    status = serverStatus, refreshKey = refreshKey,
                    onSave = { settings -> runTask("Server settings saved. Restart the server to apply them.") { controller.writeSettings(settings) } }
                )
                AppTab.DRIVE -> DrivePanel(
                    modifier = Modifier.padding(innerPadding), controller = controller,
                    refreshKey = refreshKey, busy = busy,
                    onConnect = { driveFolderPicker.launch(null) },
                    onBackup = {
                        runTask("Snapshot finished; Drive sync queued.") {
                            createSnapshotAndQueueSync(context, controller)
                        }
                    },
                    onRestore = {
                        if (serverStatus == "RUNNING") toast("Stop the server first, then refresh status and restore.")
                        else runTask("Restore request sent. Check the server control log before starting the server.") {
                            val archive = DriveBackupStore.downloadLatest(context, controller)
                            awaitControlResult(controller, controller.runControl("restore", archive.absolutePath), 300_000L)
                        }
                    },
                    onRestoreLocal = {
                        if (serverStatus == "RUNNING") toast("Stop the server first, then refresh status and restore.")
                        else runTask("Local restore request sent.") {
                            val archive = controller.latestLocalBackup() ?: error("No local backups found.")
                            awaitControlResult(controller, controller.runControl("restore", archive.absolutePath), 300_000L)
                        }
                    },
                    onRefresh = ::refreshStatus
                )
                AppTab.ACCESS -> AccessPanel(Modifier.padding(innerPadding), driveConnected = DriveBackupStore.folderUri(context) != null)
        }
    }
}

@Composable
private fun ServerPanel(
    modifier: Modifier,
    controller: ServerController,
    status: String,
    logText: String,
    busy: Boolean,
    refreshKey: Int,
    onInitializeRuntime: () -> Unit,
    onStart: () -> Unit,
    onStop: () -> Unit,
    onRefresh: () -> Unit,
    onDiagnose: () -> Unit,
    onImportJar: () -> Unit,
    onLaunchPlayit: () -> Unit,
    onStopPlayit: () -> Unit,
    onImportPlayit: () -> Unit,
    onBackup: () -> Unit,
    onAutoBackup: () -> Unit,
    onEula: (Boolean) -> Unit,
    onConsole: (String) -> Unit
) {
    var consoleCommand by rememberSaveable { mutableStateOf("say Hello from BlockHost") }
    val eulaOk = remember(refreshKey) { runCatching { controller.eulaAccepted() }.getOrDefault(false) }
    val hasJar = remember(refreshKey) { runCatching { controller.serverJarExists() }.getOrDefault(false) }
    val plugins = remember(refreshKey) { runCatching { controller.pluginFiles().size }.getOrDefault(0) }
    val backupCount = remember(refreshKey) { runCatching { controller.localBackups().size }.getOrDefault(0) }
    val runtimeReady = remember(refreshKey) { controller.runtimeReady() }
    val runtimeProgress = remember(refreshKey) { controller.runtimeProgress() }
    val prefs = LocalContext.current.getSharedPreferences(ServerController.PREFS, android.content.Context.MODE_PRIVATE)
    val autoEnabled = prefs.getBoolean(ServerController.KEY_AUTO_BACKUP, true)

    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Built-in runtime", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text(if (runtimeReady) "Status: installed" else "Status: not installed")
                Text(if (runtimeReady) "OpenJDK 21 and the Linux runtime are stored inside BlockHost's private app storage." else "First setup downloads a verified ARM64 Linux base and Java runtime into this app. It may use several hundred MB and requires internet plus at least 1.8 GB free storage.")
                if (!runtimeReady) Button(onClick = onInitializeRuntime, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("Install built-in runtime") }
                Text(runtimeProgress, style = MaterialTheme.typography.bodySmall)
            }
        }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Local server", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("Status: $status", style = MaterialTheme.typography.titleMedium)
                Text(if (hasJar) "Server JAR: installed" else "Server JAR: not imported")
                Text("Plugins: $plugins  •  Local snapshots: $backupCount")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = onStart, enabled = !busy && status != "RUNNING") { Text("Start") }
                    OutlinedButton(onClick = onStop, enabled = !busy && status == "RUNNING") { Text("Stop") }
                    OutlinedButton(onClick = onRefresh, enabled = !busy) { Text("Refresh") }
                }
                OutlinedButton(onClick = onImportJar, enabled = !busy && status == "STOPPED", modifier = Modifier.fillMaxWidth()) {
                    Text(if (hasJar) "Replace server JAR" else "Import server JAR")
                }
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Minecraft EULA", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("Only enable this after reading and accepting the official EULA. The server will refuse to start otherwise.")
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = eulaOk, onCheckedChange = onEula, enabled = !busy && status == "STOPPED")
                    Text("I have read and agree to the Minecraft EULA")
                }
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Console", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                OutlinedTextField(value = consoleCommand, onValueChange = { consoleCommand = it }, label = { Text("Minecraft command (without /)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                Button(onClick = { if (consoleCommand.isNotBlank()) onConsole(consoleCommand.trim()) }, enabled = !busy && status == "RUNNING", modifier = Modifier.fillMaxWidth()) { Text("Send command") }
                Text("The command is sent as text to the server console; it is not executed as a phone shell command.", style = MaterialTheme.typography.bodySmall)
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Playit tunnel", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("Import a Linux ARM64 Playit agent file, then start it inside BlockHost's embedded Linux runtime. On first launch, follow the claim/status URL shown in Recent control log. No separate terminal app is needed.")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = onLaunchPlayit, enabled = !busy) { Text("Start agent") }
                    OutlinedButton(onClick = onStopPlayit, enabled = !busy) { Text("Stop agent") }
                }
                OutlinedButton(onClick = onImportPlayit, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("Import agent file") }
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Snapshots", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("A snapshot asks Minecraft to flush its world, temporarily disables normal saves while the local archive is made, then resumes saving. Very large worlds can take time.")
                Button(onClick = onBackup, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("Create snapshot now") }
                OutlinedButton(onClick = onAutoBackup, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                    Text(if (autoEnabled) "Stop 15-minute local snapshots" else "Enable 15-minute local snapshots")
                }
                Text("Automatic upload to the selected cloud folder runs when Android WorkManager gets network time; it is not an exact real-time sync.", style = MaterialTheme.typography.bodySmall)
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Recent control log", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                OutlinedButton(onClick = onDiagnose, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("Run diagnostics") }
                Text(logText, style = MaterialTheme.typography.bodySmall)
                Text("Data folder: ${controller.baseDir.absolutePath}", style = MaterialTheme.typography.bodySmall)
                Text("The server and runtime are private to this app. Keep BlockHost exempt from battery optimization where available and keep the phone cooled while the server is running. Android can still stop background processes.", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun PluginPanel(
    modifier: Modifier,
    controller: ServerController,
    refreshKey: Int,
    serverStopped: Boolean,
    onImport: () -> Unit,
    onDelete: (String) -> Unit
) {
    val plugins = remember(refreshKey) { runCatching { controller.pluginFiles() }.getOrDefault(emptyList()) }
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Plugins", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Import Paper/Spigot-compatible .jar plugin files. Only use plugins from sources you trust. Restart the server after changes.")
        Button(onClick = onImport, enabled = serverStopped, modifier = Modifier.fillMaxWidth()) { Text("Add plugin JAR") }
        if (!serverStopped) Text("Refresh server status and stop the server before changing plugins.", color = MaterialTheme.colorScheme.error)
        if (plugins.isEmpty()) Text("No plugin JARs installed.")
        plugins.forEach { plugin ->
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(plugin.name, fontWeight = FontWeight.SemiBold)
                        Text(formatBytes(plugin.length()), style = MaterialTheme.typography.bodySmall)
                    }
                    OutlinedButton(onClick = { onDelete(plugin.name) }, enabled = serverStopped) { Text("Remove") }
                }
            }
        }
    }
}

@Composable
private fun SettingsPanel(
    modifier: Modifier,
    controller: ServerController,
    status: String,
    refreshKey: Int,
    onSave: (ServerSettings) -> Unit
) {
    val initial = remember(refreshKey) { runCatching { controller.readSettings() }.getOrDefault(ServerSettings()) }
    var motd by remember(refreshKey) { mutableStateOf(initial.motd) }
    var port by remember(refreshKey) { mutableStateOf(initial.port) }
    var maxPlayers by remember(refreshKey) { mutableStateOf(initial.maxPlayers) }
    var viewDistance by remember(refreshKey) { mutableStateOf(initial.viewDistance) }
    var simulationDistance by remember(refreshKey) { mutableStateOf(initial.simulationDistance) }
    var difficulty by remember(refreshKey) { mutableStateOf(initial.difficulty) }
    var onlineMode by remember(refreshKey) { mutableStateOf(initial.onlineMode) }
    var memoryMb by remember(refreshKey) { mutableStateOf(initial.memoryMb) }
    val canSave = status == "STOPPED"

    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Server settings", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("These settings write to server.properties. Stop the server and refresh status before saving; restart to apply changes.")
        Text("The heap limit is estimated from device RAM with memory reserved for Android. Start lower on small phones, especially with large plugin sets.", style = MaterialTheme.typography.bodySmall)
        SettingText("MOTD", motd, { motd = it })
        SettingText("Server port (1–65535)", port, { port = it }, numeric = true)
        SettingText("Maximum players", maxPlayers, { maxPlayers = it }, numeric = true)
        SettingText("View distance (2–32)", viewDistance, { viewDistance = it }, numeric = true)
        SettingText("Simulation distance (2–32)", simulationDistance, { simulationDistance = it }, numeric = true)
        SettingText("Java heap maximum in MiB (512–${controller.recommendedMaxHeapMb()})", memoryMb, { memoryMb = it }, numeric = true)
        Text("Difficulty")
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("peaceful", "easy", "normal", "hard").forEach { option ->
                if (difficulty == option) Button(onClick = { difficulty = option }) { Text(option) }
                else OutlinedButton(onClick = { difficulty = option }) { Text(option) }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(checked = onlineMode, onCheckedChange = { onlineMode = it })
            Spacer(Modifier.width(8.dp))
            Column {
                Text("Online-mode authentication", fontWeight = FontWeight.SemiBold)
                Text("Keep enabled for public servers; disabling it can allow username impersonation.", style = MaterialTheme.typography.bodySmall)
            }
        }
        Button(
            onClick = { onSave(ServerSettings(motd, port, maxPlayers, viewDistance, simulationDistance, difficulty, onlineMode, memoryMb)) },
            enabled = canSave,
            modifier = Modifier.fillMaxWidth()
        ) { Text("Save settings") }
        if (!canSave) Text("Saving is disabled until status reads STOPPED. Tap Refresh on the Server tab.", color = MaterialTheme.colorScheme.error)
    }
}

@Composable
private fun SettingText(label: String, value: String, onValue: (String) -> Unit, numeric: Boolean = false) {
    OutlinedTextField(
        value = value,
        onValueChange = { input -> onValue(if (numeric) input.filter { it.isDigit() }.take(5) else input.take(120)) },
        label = { Text(label) },
        modifier = Modifier.fillMaxWidth(),
        singleLine = true
    )
}

@Composable
private fun DrivePanel(
    modifier: Modifier,
    controller: ServerController,
    refreshKey: Int,
    busy: Boolean,
    onConnect: () -> Unit,
    onBackup: () -> Unit,
    onRestore: () -> Unit,
    onRestoreLocal: () -> Unit,
    onRefresh: () -> Unit
) {
    val context = LocalContext.current
    val connected = remember(refreshKey) { DriveBackupStore.folderUri(context) != null }
    val latestLocal = remember(refreshKey) { runCatching { controller.latestLocalBackup()?.name }.getOrNull() ?: "None" }
    val localCount = remember(refreshKey) { runCatching { controller.localBackups().size }.getOrDefault(0) }
    val remote = remember(refreshKey) { runCatching { DriveBackupStore.latestRemoteBackup(context)?.name }.getOrNull() ?: "None found" }
    val syncPrefs = context.getSharedPreferences(ServerController.PREFS, android.content.Context.MODE_PRIVATE)
    val syncStatus = remember(refreshKey) { syncPrefs.getString(ServerController.KEY_SYNC_STATUS, "NOT_SYNCED") ?: "NOT_SYNCED" }
    val syncDetail = remember(refreshKey) { syncPrefs.getString(ServerController.KEY_SYNC_DETAIL, "No cloud sync has run yet.") ?: "No cloud sync has run yet." }
    val lastCloudBackup = remember(refreshKey) { syncPrefs.getString(ServerController.KEY_SYNC_LAST_BACKUP, null) }

    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Cloud backups & handoff", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Cloud folder", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(if (connected) "A cloud folder is selected." else "No cloud folder connected.")
                Text("Tap Connect folder, then choose a folder in Google Drive from the Android file picker. On the other device, connect the same shared folder.")
                Button(onClick = onConnect, modifier = Modifier.fillMaxWidth()) { Text(if (connected) "Change cloud folder" else "Connect Google Drive folder") }
                Text("Latest remote backup: $remote", style = MaterialTheme.typography.bodySmall)
                Divider()
                Text("Sync status: $syncStatus", fontWeight = FontWeight.SemiBold)
                Text(syncDetail, style = MaterialTheme.typography.bodySmall)
                if (lastCloudBackup != null) Text("Last confirmed snapshot: $lastCloudBackup", style = MaterialTheme.typography.bodySmall)
            }
        }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Backup status", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("Local snapshots: $localCount")
                Text("Latest local: $latestLocal", style = MaterialTheme.typography.bodySmall)
                Button(onClick = onBackup, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("Create snapshot and sync") }
                OutlinedButton(onClick = onRefresh, modifier = Modifier.fillMaxWidth()) { Text("Refresh server status") }
                Text("The background upload checks every 15 minutes when network constraints allow. Android may delay background work, and uploads cannot happen while internet is unavailable.", style = MaterialTheme.typography.bodySmall)
            }
        }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Restore on this device", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("Restore replaces the server folder with the selected snapshot. The current server files are moved aside as a rollback copy. Do not restore while the server is running.")
                Button(onClick = onRestore, enabled = connected && !busy, modifier = Modifier.fillMaxWidth()) { Text("Download & restore latest Drive backup") }
                OutlinedButton(onClick = onRestoreLocal, enabled = localCount > 0 && !busy, modifier = Modifier.fillMaxWidth()) { Text("Restore latest local snapshot") }
            }
        }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Safe handoff", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("1. Keep 15-minute local snapshots enabled. 2. Wait for a fresh backup to upload. 3. Ensure the previous host is actually stopped, not merely disconnected from internet. 4. On the other device, connect the shared folder, restore the newest snapshot, verify settings/plugins, then start.")
                Text("Drive is a snapshot store, not a live world filesystem. If a phone loses internet, it can keep running and modifying its local world; the cloud cannot know that the process is still alive. Starting another copy too early can create two divergent worlds.", color = MaterialTheme.colorScheme.error)
            }
        }
    }
}

@Composable
private fun AccessPanel(modifier: Modifier, driveConnected: Boolean) {
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Access & collaborators", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Shared data folder", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(if (driveConnected) "Cloud folder connected on this device." else "Connect the cloud folder on the Drive tab first.")
                Text("To let another person access snapshots, share the chosen folder with their Google account from Google Drive, then have them connect that same folder in BlockHost.")
            }
        }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Access levels", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("Full server files — Drive Editor permission can modify or delete uploaded snapshots. Share only with people you trust.")
                Divider()
                Text("World/config/plugins only — not separately enforceable in this build because these files are stored together in a single server snapshot. Use a separate shared folder or add a server-side access-control service for real isolation.")
                Divider()
                Text("Start/stop only — not available remotely in this local-only build. Starting and stopping commands run on the device holding the server process. A secure remote-control service and authenticated coordinator would be required.")
            }
        }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Embedded runtime attribution", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("BlockHost uses proroot by coderredlab (v1.2.8), fetched from the upstream release and SHA-256 verified during build setup. The original license notice is included in this APK's assets. Source: github.com/coderredlab/proroot.")
            }
        }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Important", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("Google Drive folder sharing controls file access, not Minecraft console permissions or the other device's process. Do not share your Google password; share the folder with a person's own Google account instead.")
                Text("This app does not claim to provide remote start/stop ACL enforcement or automatic conflict-free host election.", color = MaterialTheme.colorScheme.error)
            }
        }
    }
}

private fun queryDisplayName(resolver: android.content.ContentResolver, uri: Uri): String {
    return try {
        resolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) cursor.getString(0) else null
        } ?: "selected-file.jar"
    } catch (_: Exception) { "selected-file.jar" }
}

private suspend fun createSnapshotAndQueueSync(context: android.content.Context, controller: ServerController) {
    val before = withContext(Dispatchers.IO) { controller.localBackups().firstOrNull()?.name }
    val requestId = withContext(Dispatchers.IO) { controller.runControl("backup") }
    awaitControlResult(controller, requestId, 300_000L)
    val newest = withContext(Dispatchers.IO) { controller.localBackups().firstOrNull() }
    if (newest == null || newest.name == before) {
        error("BlockHost reported success but no new completed snapshot was found. Check Recent control log.")
    }
    scheduleImmediateDriveSync(context)
}

private suspend fun awaitControlResult(controller: ServerController, requestId: String, timeoutMs: Long) {
    val deadline = System.currentTimeMillis() + timeoutMs
    while (System.currentTimeMillis() < deadline) {
        val exitCode = withContext(Dispatchers.IO) { controller.readControlExitCode(requestId) }
        if (exitCode != null) {
            if (exitCode != 0) {
                val log = withContext(Dispatchers.IO) { controller.recentBridgeLog() }
                error("BlockHost operation failed (exit code $exitCode).\n$log")
            }
            return
        }
        delay(250)
    }
    val log = withContext(Dispatchers.IO) { controller.recentBridgeLog() }
    error("Timed out waiting for BlockHost's embedded runtime operation. Check Recent control log and network connectivity.\n$log")
}

private fun formatBytes(bytes: Long): String = when {
    bytes >= 1024L * 1024L -> "%.1f MiB".format(bytes / (1024.0 * 1024.0))
    bytes >= 1024L -> "%.1f KiB".format(bytes / 1024.0)
    else -> "$bytes B"
}

private fun schedulePeriodicDriveSync(context: android.content.Context) {
    val constraints = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
    val request = PeriodicWorkRequestBuilder<DriveBackupWorker>(15, TimeUnit.MINUTES)
        .setConstraints(constraints)
        .build()
    WorkManager.getInstance(context).enqueueUniquePeriodicWork(
        "blockhost-drive-snapshot-sync", ExistingPeriodicWorkPolicy.UPDATE, request
    )
}

private fun scheduleImmediateDriveSync(context: android.content.Context) {
    context.getSharedPreferences(ServerController.PREFS, android.content.Context.MODE_PRIVATE)
        .edit()
        .putString(ServerController.KEY_SYNC_STATUS, "QUEUED")
        .putString(ServerController.KEY_SYNC_DETAIL, "Waiting for Android to run cloud sync on a working network.")
        .commit()
    val constraints = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
    val request = OneTimeWorkRequestBuilder<DriveBackupWorker>().setConstraints(constraints).build()
    WorkManager.getInstance(context).enqueueUniqueWork("blockhost-drive-snapshot-upload", ExistingWorkPolicy.REPLACE, request)
}

