package com.blockhost.app

import android.app.ActivityManager
import android.content.Context
import android.net.Uri
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.util.Properties
import java.util.UUID
import java.util.zip.ZipFile
import androidx.core.content.ContextCompat

/** All world/server files stay in this app's private storage by default. */
data class ServerSettings(
    val motd: String = "A Minecraft server powered by BlockHost",
    val port: String = "25565",
    val maxPlayers: String = "8",
    val viewDistance: String = "6",
    val simulationDistance: String = "4",
    val difficulty: String = "normal",
    val onlineMode: Boolean = true,
    val memoryMb: String = "1536"
)

class ServerController(private val context: Context) {
    val baseDir: File = File(context.filesDir, "blockhost")
    val serverDir: File get() = File(baseDir, "server")
    val pluginsDir: File get() = File(serverDir, "plugins")
    val backupsDir: File get() = File(baseDir, "backups")
    val controlResultsDir: File get() = File(baseDir, "control-results")
    val consoleLog: File get() = File(serverDir, "logs/console.log")

    /** No broad-storage permission is needed because the server is private to this app. */
    fun storageAvailable(): Boolean = true
    fun runtimeReady(): Boolean = RuntimeManager.isInstalled(context)
    fun getPreferences() = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    fun runtimeProgress(): String = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .getString(KEY_RUNTIME_PROGRESS, if (runtimeReady()) "Ready" else "Not installed") ?: "Not installed"

    fun ensureLayout() {
        listOf(baseDir, serverDir, pluginsDir, backupsDir, controlResultsDir, File(serverDir, "logs"), File(baseDir, "bin"))
            .forEach { check(it.exists() || it.mkdirs()) { "Could not create app-private directory: ${it.path}" } }
        val props = File(serverDir, "server.properties")
        if (!props.exists()) writeTextAtomically(
            props,
            "motd=A Minecraft server powered by BlockHost\n" +
                "server-port=25565\nmax-players=8\nview-distance=6\nsimulation-distance=4\n" +
                "difficulty=normal\nonline-mode=true\nserver-ip=\n"
        )
        val eula = File(serverDir, "eula.txt")
        if (!eula.exists()) writeTextAtomically(
            eula,
            "# Set eula=true only after reading and accepting the Minecraft EULA.\neula=false\n"
        )
    }

    fun importServerJar(uri: Uri) {
        ensureLayout()
        check(readStatus() == "STOPPED") { "Stop the server before replacing its JAR." }
        val target = File(serverDir, "server.jar")
        val staged = File(serverDir, ".server.jar.importing")
        try {
            copyUriToFile(uri, staged)
            verifyJar(staged)
            moveReplace(staged, target)
        } finally { staged.delete() }
    }

    fun importPlugin(uri: Uri, displayName: String) {
        ensureLayout()
        check(readStatus() == "STOPPED") { "Stop the server before changing plugins." }
        require(displayName.lowercase().endsWith(".jar")) { "Choose a .jar plugin file." }
        val safeName = displayName.replace(Regex("[^A-Za-z0-9._ -]"), "_").trim().ifBlank { "plugin.jar" }
        require(safeName != "." && safeName != "..") { "Invalid plugin filename." }
        val target = File(pluginsDir, safeName)
        val staged = File(pluginsDir, ".$safeName.importing")
        try {
            copyUriToFile(uri, staged)
            verifyJar(staged)
            moveReplace(staged, target)
        } finally { staged.delete() }
    }

    private fun copyUriToFile(uri: Uri, staged: File) {
        staged.parentFile?.mkdirs()
        context.contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "Could not open selected file." }
            FileOutputStream(staged).use { output ->
                input.copyTo(output, 128 * 1024)
                output.fd.sync()
            }
        }
        require(staged.isFile && staged.length() > 0) { "Selected file is empty." }
    }

    private fun verifyJar(file: File) {
        require(file.isFile && file.length() > 0L) { "The selected JAR is empty." }
        ZipFile(file).use { zip ->
            require(zip.size() > 0) { "The JAR archive is empty or invalid." }
            require(zip.getEntry("META-INF/MANIFEST.MF") != null || zip.entries().hasMoreElements()) { "The archive does not look like a JAR." }
        }
    }

    fun importPlayitBinary(uri: Uri) {
        ensureLayout()
        val target = File(baseDir, "bin/playit")
        val staged = File(target.parentFile, ".playit.importing")
        try {
            copyUriToFile(uri, staged)
            require(staged.length() >= 4L) { "The selected file is too small to be a Playit executable." }
            val header = ByteArray(20)
            FileInputStream(staged).use { input ->
                var offset = 0
                while (offset < header.size) {
                    val count = input.read(header, offset, header.size - offset)
                    if (count < 0) break
                    offset += count
                }
                require(offset == header.size) { "The selected file is too small to contain an ELF header." }
            }
            val magicOk = header[0] == 0x7f.toByte() && header[1] == 0x45.toByte() &&
                header[2] == 0x4c.toByte() && header[3] == 0x46.toByte()
            val is64BitLittleEndian = header[4] == 2.toByte() && header[5] == 1.toByte()
            val isArm64 = (header[18].toInt() and 0xff) == 0xb7 && (header[19].toInt() and 0xff) == 0x00
            require(magicOk && is64BitLittleEndian && isArm64) {
                "Choose a Linux ARM64 (AArch64), 64-bit little-endian Playit executable. APKs, JARs and x86 binaries are not supported."
            }
            moveReplace(staged, target)
            target.setReadable(true, false)
            check(target.setExecutable(true, false)) { "Could not mark the Playit agent executable." }
        } finally { staged.delete() }
    }

    fun recommendedMaxHeapMb(): Int {
        val manager = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val info = ActivityManager.MemoryInfo()
        manager?.getMemoryInfo(info)
        val totalMb = if (info.totalMem > 0L) (info.totalMem / (1024L * 1024L)).toInt() else 4096
        val availableMb = if (info.availMem > 0L) (info.availMem / (1024L * 1024L)).toInt() else totalMb / 2
        // Avoid assigning more than total RAM minus 1.5 GiB or current available RAM minus 512 MiB.
        return minOf(totalMb - 1536, availableMb - 512, 8192).coerceAtLeast(512)
    }

    fun pluginFiles(): List<File> = pluginsDir.listFiles()
        ?.filter { it.isFile && it.extension.equals("jar", true) }
        ?.sortedBy { it.name.lowercase() }
        ?: emptyList()

    fun deletePlugin(name: String) {
        check(readStatus() == "STOPPED") { "Stop the server before changing plugins." }
        val safeName = File(name).name
        val file = File(pluginsDir, safeName)
        require(file.parentFile?.canonicalFile == pluginsDir.canonicalFile) { "Invalid plugin path." }
        if (file.exists()) check(file.delete()) { "Could not delete plugin." }
    }

    fun readSettings(): ServerSettings {
        ensureLayout()
        val p = Properties()
        File(serverDir, "server.properties").inputStream().use { p.load(it) }
        val heap = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_RAM, "1536")?.toIntOrNull() ?: 1536
        return ServerSettings(
            motd = p.getProperty("motd", ServerSettings().motd),
            port = p.getProperty("server-port", "25565"),
            maxPlayers = p.getProperty("max-players", "8"),
            viewDistance = p.getProperty("view-distance", "6"),
            simulationDistance = p.getProperty("simulation-distance", "4"),
            difficulty = p.getProperty("difficulty", "normal"),
            onlineMode = p.getProperty("online-mode", "true").toBooleanStrictOrNull() ?: true,
            memoryMb = heap.coerceIn(512, recommendedMaxHeapMb()).toString()
        )
    }

    fun writeSettings(settings: ServerSettings) {
        ensureLayout()
        check(readStatus() == "STOPPED") { "Server settings can only be changed while the server is stopped. Refresh status first." }
        val port = settings.port.toIntOrNull()?.takeIf { it in 1..65535 } ?: error("Port must be between 1 and 65535.")
        val players = settings.maxPlayers.toIntOrNull()?.takeIf { it in 1..1000 } ?: error("Maximum players must be between 1 and 1000.")
        val view = settings.viewDistance.toIntOrNull()?.takeIf { it in 2..32 } ?: error("View distance must be between 2 and 32.")
        val simulation = settings.simulationDistance.toIntOrNull()?.takeIf { it in 2..32 } ?: error("Simulation distance must be between 2 and 32.")
        val maxHeap = recommendedMaxHeapMb()
        val memory = settings.memoryMb.toIntOrNull()?.takeIf { it in 512..maxHeap } ?: error("Choose a heap between 512 and $maxHeap MiB.")
        val difficulty = settings.difficulty.lowercase().takeIf { it in setOf("peaceful", "easy", "normal", "hard") } ?: "normal"
        val file = File(serverDir, "server.properties")
        val p = Properties()
        if (file.exists()) file.inputStream().use { p.load(it) }
        p.setProperty("motd", settings.motd.replace(Regex("[\\r\\n]"), " ").take(120))
        p.setProperty("server-port", port.toString())
        p.setProperty("max-players", players.toString())
        p.setProperty("view-distance", view.toString())
        p.setProperty("simulation-distance", simulation.toString())
        p.setProperty("difficulty", difficulty)
        p.setProperty("online-mode", settings.onlineMode.toString())
        p.setProperty("server-ip", "")
        val staged = File(serverDir, ".server.properties.tmp")
        FileOutputStream(staged).use { output -> p.store(output, "BlockHost server settings") ; output.fd.sync() }
        moveReplace(staged, file)
        check(context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_RAM, memory.toString()).commit()) {
            "Could not save the Java heap setting."
        }
    }

    fun eulaAccepted(): Boolean {
        val file = File(serverDir, "eula.txt")
        return file.exists() && Regex("(?m)^\\s*eula\\s*=\\s*true\\s*$", RegexOption.IGNORE_CASE).containsMatchIn(file.readText())
    }

    fun setEulaAccepted(accepted: Boolean) {
        ensureLayout()
        check(readStatus() == "STOPPED") { "Stop the server before changing the EULA setting." }
        writeTextAtomically(
            File(serverDir, "eula.txt"),
            "# Read the Minecraft EULA at https://aka.ms/MinecraftEULA before accepting.\neula=$accepted\n"
        )
    }

    fun serverJarExists(): Boolean = File(serverDir, "server.jar").let { it.isFile && it.length() > 0L }

    fun localBackups(): List<File> = backupsDir.listFiles()
        ?.filter { it.isFile && it.name.startsWith("BlockHost-") && it.name.endsWith(".tar.gz") && !it.name.contains(".uploading") }
        ?.sortedByDescending { it.name }
        ?: emptyList()

    fun latestLocalBackup(): File? {
        val safeParent = runCatching { backupsDir.canonicalFile }.getOrNull() ?: return null
        val marker = File(baseDir, "latest_backup.txt")
        val candidate = marker.takeIf { it.isFile }?.readText()?.trim()?.takeIf { it.isNotBlank() }?.let(::File)
        return candidate?.takeIf {
            runCatching {
                it.isFile && it.name.startsWith("BlockHost-") && it.name.endsWith(".tar.gz") && it.canonicalFile.parentFile == safeParent
            }.getOrDefault(false)
        } ?: localBackups().firstOrNull()
    }

    /** Dispatch an operation to this app's own foreground service, never another package. */
    fun runControl(action: String, vararg args: String): String {
        ensureLayout()
        require(action in ALLOWED_ACTIONS) { "Unsupported server action." }
        val requestId = UUID.randomUUID().toString()
        File(controlResultsDir, "$requestId.result").delete()
        val intent = android.content.Intent(context, StandaloneServerService::class.java).apply {
            this.action = StandaloneServerService.ACTION_REQUEST
            putExtra(StandaloneServerService.EXTRA_OPERATION, action)
            putExtra(StandaloneServerService.EXTRA_REQUEST_ID, requestId)
            putStringArrayListExtra(StandaloneServerService.EXTRA_ARGUMENTS, ArrayList(args.toList()))
        }
        try {
            ContextCompat.startForegroundService(context, intent)
        } catch (error: Exception) {
            throw IllegalStateException("Could not start BlockHost's own server service: ${error.message ?: error.javaClass.simpleName}", error)
        }
        return requestId
    }

    fun readControlExitCode(requestId: String): Int? {
        if (!requestId.matches(Regex("^[0-9a-fA-F-]{36}$"))) return null
        val resultFile = File(controlResultsDir, "$requestId.result")
        if (!resultFile.isFile) return null
        val parts = runCatching { resultFile.readText().trim().split('|', limit = 2) }.getOrNull() ?: return null
        if (parts.size != 2 || parts[0] != requestId) return null
        return parts[1].toIntOrNull()
    }

    fun writeControlResult(requestId: String, exitCode: Int) {
        if (!requestId.matches(Regex("^[0-9a-fA-F-]{36}$"))) return
        val resultDir = controlResultsDir.apply { mkdirs() }
        val staged = File(resultDir, ".$requestId.tmp")
        val target = File(resultDir, "$requestId.result")
        try {
            FileOutputStream(staged).use { out ->
                out.write("$requestId|$exitCode\n".toByteArray(Charsets.UTF_8))
                out.fd.sync()
            }
            moveReplace(staged, target)
        } finally { staged.delete() }
        resultDir.listFiles()?.filter { it.isFile && it.name.endsWith(".result") }
            ?.sortedByDescending { it.lastModified() }?.drop(80)?.forEach { it.delete() }
    }

    fun readStatus(): String {
        val file = File(baseDir, "server_status.txt")
        return file.takeIf { it.isFile }?.readText()?.trim()?.takeIf { it.isNotBlank() } ?: "STOPPED"
    }

    fun writeStatus(value: String) {
        require(value in setOf("STOPPED", "STARTING", "RUNNING", "STOPPING", "ERROR", "INSTALLING", "READY"))
        writeTextAtomically(File(baseDir, "server_status.txt"), "$value\n")
    }

    fun recentBridgeLog(): String = readTail(File(baseDir, "bridge.log"), 5000, 2200)
    fun recentConsoleLog(): String = readTail(consoleLog, 6000, 2500)

    fun appendBridgeLog(message: String) = appendLine(File(baseDir, "bridge.log"), message)
    fun appendConsoleLog(message: String) = appendLine(consoleLog, message)

    private fun appendLine(file: File, message: String) {
        synchronized(LOG_LOCK) {
            file.parentFile?.mkdirs()
            if (file.isFile && file.length() > 5L * 1024L * 1024L) {
                val previous = File(file.parentFile, file.name + ".1")
                previous.delete()
                moveReplace(file, previous)
            }
            file.appendText("${System.currentTimeMillis()} ${message.take(3500)}\n", Charsets.UTF_8)
        }
    }

    private fun readTail(file: File, maxBytes: Int, maxChars: Int): String {
        if (!file.isFile) return "No output yet."
        return runCatching {
            java.io.RandomAccessFile(file, "r").use { input ->
                val start = (input.length() - maxBytes.toLong()).coerceAtLeast(0L)
                input.seek(start)
                val bytes = ByteArray((input.length() - start).toInt())
                input.readFully(bytes)
                String(bytes, Charsets.UTF_8).takeLast(maxChars).ifBlank { "No output yet." }
            }
        }.getOrElse { "Could not read log: ${it.message ?: "unknown error"}" }
    }

    private fun writeTextAtomically(target: File, value: String) {
        val staged = File(target.parentFile, ".${target.name}.tmp")
        try {
            FileOutputStream(staged).use { output ->
                output.write(value.toByteArray(Charsets.UTF_8))
                output.fd.sync()
            }
            moveReplace(staged, target)
        } finally { staged.delete() }
    }

    private fun moveReplace(staged: File, target: File) {
        try { Files.move(staged.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE) }
        catch (_: Exception) { Files.move(staged.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING) }
    }

    companion object {
        private val LOG_LOCK = Any()
        val ALLOWED_ACTIONS = setOf("install-runtime", "start", "stop", "status", "cmd", "backup", "autobackup-start", "autobackup-stop", "playit", "stop-playit", "doctor", "restore")
        const val PREFS = "blockhost_preferences"
        const val KEY_RAM = "server_ram_mb"
        const val KEY_DRIVE_TREE = "drive_tree_uri"
        const val KEY_LAST_UPLOADED = "last_uploaded_backup_key"
        const val KEY_LAST_UPLOADED_SOURCE = "last_uploaded_backup_source_signature"
        const val KEY_SYNC_STATUS = "drive_sync_status"
        const val KEY_SYNC_DETAIL = "drive_sync_detail"
        const val KEY_SYNC_LAST_SUCCESS = "drive_sync_last_success_ms"
        const val KEY_SYNC_LAST_BACKUP = "drive_sync_last_backup"
        const val KEY_AUTO_BACKUP = "auto_backup_enabled"
        const val KEY_RUNTIME_PROGRESS = "runtime_progress"
        const val KEY_RUNTIME_STATUS = "runtime_status"
    }
}
