package com.blockhost.app

import android.content.Context
import android.net.ConnectivityManager
import android.os.Build
import org.apache.commons.compress.archivers.tar.TarArchiveEntry
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.security.MessageDigest
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Ubuntu Base and OpenJDK are installed into this app's private storage. No terminal/hosting
 * app is used. PRoot-compatible native launchers are downloaded and SHA-256 verified at build
 * setup, packaged through jniLibs, extracted by Android into nativeLibraryDir, then re-verified
 * before execution. Ubuntu Base is checked against Canonical's SHA256SUMS before extraction.
 */
object RuntimeManager {
    private const val PROOT_RELEASE = "v1.2.8"
    private const val UBUNTU_RELEASE = "24.04"
    private const val UBUNTU_IMAGE = "ubuntu-base-24.04.5-base-arm64.tar.gz"
    private const val UBUNTU_RELEASE_URL = "https://cdimages.ubuntu.com/ubuntu-base/releases/$UBUNTU_RELEASE/release"

    private val expectedToolHashes = linkedMapOf(
        "libproroot.so" to "a4e74d75b66cdc02b080adfe863dbf9951c3b30610d77beddc95488d5fe5de01",
        "libproroot-runtime.so" to "8c47a0a7db32d84c179ebb5bf3640f655a3181860ece5886ae44d92858730c34",
        "libproroot-bridge.so" to "1c5bc9537a270e8bf8b1c70222813f57b60b828bfb5503ddf8fe37685092de2f",
        "libproroot-linker.so" to "51a0ec5bfed00e572a0de09e22d9057e2befc386b78e426613d3e0ab03f4ecee",
        "libproroot-stub-loader.so" to "06c6624db3bdc45b9ced151cd781df439a37b47731d244b93e9d6a58cd48cde2"
    )

    fun runtimeDir(context: Context) = File(context.filesDir, "embedded-runtime")
    // Android 10+ blocks execve() for binaries copied into writable filesDir. These unchanged
    // native assets must be packaged under jniLibs/arm64-v8a so PackageManager extracts them
    // into nativeLibraryDir, which is the executable location for this Android app.
    fun toolsDir(context: Context) = File(context.applicationInfo.nativeLibraryDir)
    fun rootfsDir(context: Context) = File(runtimeDir(context), "rootfs")
    fun prootLauncher(context: Context) = File(toolsDir(context), "libproroot.so")

    fun isInstalled(context: Context): Boolean {
        if (Build.SUPPORTED_ABIS.none { it == "arm64-v8a" }) return false
        val runtime = runtimeDir(context)
        return File(runtime, "runtime-ready").isFile &&
            prootLauncher(context).isFile && prootLauncher(context).canExecute() &&
            rootfsDir(context).let { File(it, "usr/bin/java").isFile }
    }

    fun unsupportedReason(): String? = if (Build.SUPPORTED_ABIS.none { it == "arm64-v8a" }) {
        "This embedded runtime currently supports 64-bit ARM Android devices (arm64-v8a)."
    } else null

    suspend fun install(context: Context, progress: (String) -> Unit) = withContext(Dispatchers.IO) {
        unsupportedReason()?.let { error(it) }
        val runtime = runtimeDir(context)
        val tools = toolsDir(context)
        val rootfs = rootfsDir(context)
        check(runtime.mkdirs() || runtime.isDirectory) { "Cannot create app-private runtime directory." }
        check(tools.isDirectory) {
            "The embedded ARM64 launcher assets are missing from this APK. Re-run setup-wrapper.ps1 or setup-wrapper.sh, then rebuild the APK."
        }
        check(runtime.usableSpace >= 1_800L * 1024L * 1024L) {
            "Free at least 1.8 GB in device storage before installing the embedded Java runtime."
        }
        File(runtime, "runtime-ready").delete()

        progress("Verifying embedded ARM64 runtime tools…")
        expectedToolHashes.forEach { (name, expectedHash) ->
            val target = File(tools, name)
            check(target.isFile && sha256(target).equals(expectedHash, ignoreCase = true)) {
                "Embedded runtime asset $name is missing or failed SHA-256 verification. Re-run setup-wrapper and rebuild the APK."
            }
        }
        check(prootLauncher(context).canExecute()) {
            "Android did not extract the native launcher as executable. Check jniLibs packaging configuration."
        }

        progress("Checking the official Ubuntu Base checksum…")
        val sumsFile = File(runtime, "ubuntu-SHA256SUMS.tmp")
        download("$UBUNTU_RELEASE_URL/SHA256SUMS", sumsFile)
        val expectedRootfsHash = sumsFile.readLines().firstNotNullOfOrNull { line ->
            val match = Regex("^([0-9a-fA-F]{64})\\s+\\*?${Regex.escape(UBUNTU_IMAGE)}\\s*$").find(line.trim())
            match?.groupValues?.get(1)
        } ?: error("Canonical's checksum file did not list $UBUNTU_IMAGE.")

        val rootfsMarker = File(rootfs, "var/lib/dpkg/status")
        if (!rootfsMarker.isFile) {
            val archive = File(runtime, UBUNTU_IMAGE)
            val stagedArchive = File(runtime, "$UBUNTU_IMAGE.download")
            if (!archive.isFile || !sha256(archive).equals(expectedRootfsHash, ignoreCase = true)) {
                stagedArchive.delete()
                progress("Downloading Ubuntu ARM64 base image… this is about 30 MB.")
                download("$UBUNTU_RELEASE_URL/$UBUNTU_IMAGE", stagedArchive) { received, total ->
                    if (total > 0L) progress("Downloading Ubuntu base: ${received * 100 / total}%")
                }
                if (!sha256(stagedArchive).equals(expectedRootfsHash, ignoreCase = true)) {
                    stagedArchive.delete()
                    error("Ubuntu Base SHA-256 verification failed. The archive was rejected.")
                }
                moveReplace(stagedArchive, archive)
            }
            progress("Extracting verified Ubuntu base into BlockHost's private storage…")
            if (rootfs.exists()) rootfs.deleteRecursively()
            val stagingRoot = File(runtime, "rootfs-installing")
            stagingRoot.deleteRecursively()
            check(stagingRoot.mkdirs()) { "Cannot create root filesystem staging directory." }
            extractTarGzSafely(archive, stagingRoot) { extracted, total ->
                if (total > 0L) progress("Extracting Ubuntu base: ${extracted * 100 / total}%")
            }
            check(File(stagingRoot, "var/lib/dpkg/status").isFile) { "Ubuntu Base archive did not contain the expected package database." }
            moveReplace(stagingRoot, rootfs)
            archive.delete()
        }
        sumsFile.delete()

        progress("Preparing network and package sources…")
        configureRootfs(context, rootfs)
        progress("Installing OpenJDK 21 and runtime utilities…")
        val installScript = """
            set -e
            export DEBIAN_FRONTEND=noninteractive
            apt-get -o Acquire::Retries=3 update
            apt-get -o Acquire::Retries=3 install -y --no-install-recommends openjdk-21-jre-headless ca-certificates tzdata tar gzip coreutils findutils procps
            /usr/bin/java -version
            apt-get clean
            rm -rf /var/lib/apt/lists/* /var/cache/apt/archives/*.deb
        """.trimIndent()
        val code = runGuestCommand(context, listOf("/bin/sh", "-lc", installScript), output = progress)
        check(code == 0) { "OpenJDK installation failed (exit $code). Check internet connectivity and the runtime log, then retry setup." }
        check(File(rootfs, "usr/bin/java").isFile) { "Java did not install correctly." }
        File(runtime, "runtime-ready.tmp").writeText("ubuntu=$UBUNTU_RELEASE\nproot=$PROOT_RELEASE\njava=21\n")
        moveReplace(File(runtime, "runtime-ready.tmp"), File(runtime, "runtime-ready"))
        progress("Embedded runtime installed. No separate terminal app is needed.")
    }

    fun createProcess(
        context: Context,
        guestCommand: List<String>,
        binds: List<Pair<File, String>> = emptyList(),
        workingDirectory: String = "/root"
    ): Process {
        check(prootLauncher(context).isFile && rootfsDir(context).isDirectory) { "Install the built-in runtime first." }
        val rootfs = rootfsDir(context)
        val command = arrayListOf(
            prootLauncher(context).absolutePath,
            "-r", rootfs.absolutePath,
            "-0", "--link2symlink",
            "-b", "/dev",
            "-b", "/proc",
            "-b", "/sys"
        )
        binds.forEach { (host, guest) ->
            check(host.isAbsolute && guest.startsWith("/")) { "Invalid runtime bind path." }
            command.add("-b")
            command.add("${host.absolutePath}:$guest")
        }
        command.add("-w")
        command.add(workingDirectory)
        command.addAll(guestCommand)
        val process = ProcessBuilder(command).redirectErrorStream(true)
        process.environment()["PROROOT_TMP_DIR"] = File(runtimeDir(context), "tmp").apply { mkdirs() }.absolutePath
        process.environment()["PROROOT_LOG_APPEND"] = File(runtimeDir(context), "proroot.log").absolutePath
        process.environment()["HOME"] = "/root"
        process.environment()["TMPDIR"] = "/tmp"
        // Do not inherit Android's /system/bin-first PATH into Ubuntu commands such as apt-get.
        process.environment()["PATH"] = "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
        process.environment()["LANG"] = "C.UTF-8"
        process.environment()["LC_ALL"] = "C.UTF-8"
        return process.start()
    }

    suspend fun runGuestCommand(
        context: Context,
        command: List<String>,
        binds: List<Pair<File, String>> = emptyList(),
        workingDirectory: String = "/root",
        output: (String) -> Unit = {}
    ): Int = withContext(Dispatchers.IO) {
        val process = createProcess(context, command, binds, workingDirectory)
        process.inputStream.bufferedReader().useLines { lines ->
            lines.forEach { line -> output(line.take(1800)) }
        }
        process.waitFor()
    }

    private fun configureRootfs(context: Context, rootfs: File) {
        val etc = File(rootfs, "etc")
        check(etc.mkdirs() || etc.isDirectory)
        File(etc, "apt/sources.list.d").mkdirs()
        File(etc, "apt/sources.list").writeText(
            "deb http://ports.ubuntu.com/ubuntu-ports noble main restricted universe multiverse\n" +
                "deb http://ports.ubuntu.com/ubuntu-ports noble-updates main restricted universe multiverse\n" +
                "deb http://ports.ubuntu.com/ubuntu-ports noble-security main restricted universe multiverse\n"
        )
        File(etc, "apt/apt.conf.d/99blockhost").apply {
            parentFile?.mkdirs()
            writeText("Acquire::Retries \"3\";\nAcquire::http::Timeout \"30\";\nAcquire::https::Timeout \"30\";\n")
        }
        val dns = activeDnsServers(context).ifEmpty { listOf("1.1.1.1", "8.8.8.8") }
        val resolv = File(etc, "resolv.conf")
        runCatching { if (Files.isSymbolicLink(resolv.toPath())) Files.delete(resolv.toPath()) }
        resolv.writeText(dns.distinct().joinToString("\n") { "nameserver $it" } + "\noptions timeout:2 attempts:3\n")
        File(etc, "hosts").writeText("127.0.0.1 localhost\n::1 localhost ip6-localhost ip6-loopback\n")
        File(rootfs, "tmp").mkdirs()
        File(rootfs, "dev").mkdirs()
        File(rootfs, "proc").mkdirs()
        File(rootfs, "sys").mkdirs()
        File(rootfs, "root").mkdirs()
    }

    private fun activeDnsServers(context: Context): List<String> = runCatching {
        val manager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = manager.activeNetwork ?: return@runCatching emptyList()
        manager.getLinkProperties(network)?.dnsServers
            ?.map { it.hostAddress.orEmpty().substringBefore('%') }
            ?.filter { it.isNotBlank() && !it.startsWith("fe80:", ignoreCase = true) }
            .orEmpty()
    }.getOrDefault(emptyList())

    private fun download(url: String, target: File, progress: (Long, Long) -> Unit = { _, _ -> }) {
        val connection = URL(url).openConnection() as HttpURLConnection
        try {
            connection.connectTimeout = 25_000
            connection.readTimeout = 60_000
            connection.instanceFollowRedirects = true
            connection.setRequestProperty("User-Agent", "BlockHost-Android")
            val code = connection.responseCode
            check(code in 200..299) { "Download failed (HTTP $code): $url" }
            val total = connection.contentLengthLong
            target.parentFile?.mkdirs()
            FileOutputStream(target).use { output ->
                connection.inputStream.use { input ->
                    val buffer = ByteArray(128 * 1024)
                    var received = 0L
                    while (true) {
                        val count = input.read(buffer)
                        if (count < 0) break
                        output.write(buffer, 0, count)
                        received += count
                        if (total > 0L) progress(received, total)
                    }
                }
                output.fd.sync()
            }
            check(target.length() > 0L) { "Downloaded file is empty: $url" }
        } catch (error: Exception) {
            target.delete()
            throw error
        } finally {
            connection.disconnect()
        }
    }

    private fun extractTarGzSafely(archive: File, destination: File, progress: (Long, Long) -> Unit) {
        val base = destination.toPath().toAbsolutePath().normalize()
        val total = archive.length().coerceAtLeast(1L)
        var readBytes = 0L
        TarArchiveInputStream(GzipCompressorInputStream(BufferedInputStream(FileInputStream(archive)))).use { tar ->
            var entry: TarArchiveEntry? = tar.nextTarEntry
            val buffer = ByteArray(64 * 1024)
            while (entry != null) {
                val name = entry.name.replace('\\', '/')
                val relative = java.nio.file.Paths.get(name).normalize()
                require(!relative.isAbsolute && relative.nameCount > 0 && relative.toString() != ".." && !relative.startsWith("..")) {
                    "Unsafe path inside Ubuntu Base archive: $name"
                }
                val target = base.resolve(relative).normalize()
                require(target.startsWith(base)) { "Unsafe path inside Ubuntu Base archive: $name" }
                when {
                    entry.isDirectory -> check(target.toFile().mkdirs() || target.toFile().isDirectory)
                    entry.isSymbolicLink -> {
                        target.parent?.let { Files.createDirectories(it) }
                        if (Files.exists(target)) Files.delete(target)
                        Files.createSymbolicLink(target, java.nio.file.Paths.get(entry.linkName))
                    }
                    entry.isLink -> {
                        target.parent?.let { Files.createDirectories(it) }
                        val linkTarget = base.resolve(entry.linkName).normalize()
                        require(linkTarget.startsWith(base)) { "Unsafe hard link inside Ubuntu Base archive." }
                        Files.createLink(target, linkTarget)
                    }
                    entry.isFile -> {
                        target.parent?.let { Files.createDirectories(it) }
                        BufferedOutputStream(FileOutputStream(target.toFile())).use { output ->
                            while (true) {
                                val count = tar.read(buffer)
                                if (count < 0) break
                                output.write(buffer, 0, count)
                                readBytes += count
                                if (readBytes % (4L * 1024 * 1024) < buffer.size) progress(readBytes, total)
                            }
                        }
                        target.toFile().setReadable(true, true)
                        if ((entry.mode and 73) != 0) target.toFile().setExecutable(true, true)
                    }
                    else -> Unit // Ignore device nodes and other special entries; Android apps cannot create them.
                }
                entry = tar.nextTarEntry
            }
        }
        progress(total, total)
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { input ->
            val buffer = ByteArray(128 * 1024)
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                digest.update(buffer, 0, count)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(Locale.ROOT, it.toInt() and 0xff) }
    }

    private fun moveReplace(from: File, to: File) {
        try {
            Files.move(from.toPath(), to.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE)
        } catch (_: Exception) {
            Files.move(from.toPath(), to.toPath(), StandardCopyOption.REPLACE_EXISTING)
        }
    }
}
