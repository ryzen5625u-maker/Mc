package com.blockhost.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.DigestInputStream
import java.security.MessageDigest
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.util.UUID
import java.util.zip.GZIPInputStream

/** Google Drive is used as a snapshot destination, never as the live world directory. */
object DriveBackupStore {
    private const val BACKUP_PREFIX = "BlockHost-"
    private const val BACKUP_SUFFIX = ".tar.gz"
    private val hashSuffix = Regex("-([a-f0-9]{12})\\.tar\\.gz$", RegexOption.IGNORE_CASE)

    fun saveFolder(context: Context, uri: Uri) {
        context.contentResolver.takePersistableUriPermission(
            uri,
            Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
        )
        val saved = context.getSharedPreferences(ServerController.PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(ServerController.KEY_DRIVE_TREE, uri.toString())
            .remove(ServerController.KEY_LAST_UPLOADED)
            .remove(ServerController.KEY_LAST_UPLOADED_SOURCE)
            .remove(ServerController.KEY_SYNC_LAST_BACKUP)
            .remove(ServerController.KEY_SYNC_LAST_SUCCESS)
            .commit()
        check(saved) { "Could not save the selected cloud folder." }
    }

    fun folderUri(context: Context): Uri? = context.getSharedPreferences(ServerController.PREFS, Context.MODE_PRIVATE)
        .getString(ServerController.KEY_DRIVE_TREE, null)?.let(Uri::parse)

    fun folderLabel(context: Context): String = if (folderUri(context) == null) "Not connected" else "Connected folder selected"

    fun latestRemoteBackup(context: Context): DocumentFile? {
        val treeUri = folderUri(context) ?: return null
        val tree = DocumentFile.fromTreeUri(context, treeUri) ?: return null
        return tree.listFiles()
            .filter { file -> file.isFile && isBackupName(file.name.orEmpty()) }
            .maxByOrNull { it.name.orEmpty() }
    }

    fun downloadLatest(context: Context, controller: ServerController): File {
        val remote = latestRemoteBackup(context) ?: error("No completed BlockHost backup was found in the selected cloud folder.")
        controller.ensureLayout()
        val safeName = File(remote.name ?: "").name
        require(isBackupName(safeName)) { "Unexpected backup filename." }
        val local = File(controller.backupsDir, safeName)
        val staged = File(controller.backupsDir, ".$safeName.downloading")
        try {
            context.contentResolver.openInputStream(remote.uri).use { input ->
                requireNotNull(input) { "Could not open the cloud backup." }
                FileOutputStream(staged).use { output ->
                    input.copyTo(output)
                    output.fd.sync()
                }
            }
            require(staged.length() > 0L) { "Downloaded backup is empty." }
            validateGzipArchive(staged)
            // New-format filenames carry a short hash. Legacy snapshots remain importable but still get gzip validation.
            hashSuffix.find(safeName)?.groupValues?.getOrNull(1)?.let { expectedPrefix ->
                require(sha256(staged).startsWith(expectedPrefix, ignoreCase = true)) {
                    "Cloud snapshot checksum does not match its filename. The download was not installed."
                }
            }
            moveReplace(staged, local)
            writeLatestMarker(controller, local)
            return local
        } finally {
            staged.delete()
        }
    }

    private fun isBackupName(name: String): Boolean =
        name.startsWith(BACKUP_PREFIX) && name.endsWith(BACKUP_SUFFIX) && !name.contains(".uploading")

    private fun validateGzipArchive(file: File) {
        GZIPInputStream(FileInputStream(file)).use { gzip ->
            val buffer = ByteArray(64 * 1024)
            while (gzip.read(buffer) != -1) { /* read through EOF to verify gzip CRC/trailer */ }
        }
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        DigestInputStream(FileInputStream(file), digest).use { input ->
            val buffer = ByteArray(128 * 1024)
            while (input.read(buffer) != -1) { /* stream; do not load world archives into RAM */ }
        }
        return digest.digest().joinToString("") { byte -> "%02x".format(byte.toInt() and 0xff) }
    }

    private fun sha256(uri: Uri, context: Context): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val source = context.contentResolver.openInputStream(uri)
            ?: error("Could not verify the uploaded cloud file.")
        DigestInputStream(source, digest).use { input ->
            val buffer = ByteArray(128 * 1024)
            while (input.read(buffer) != -1) { /* read back the provider's completed copy */ }
        }
        return digest.digest().joinToString("") { byte -> "%02x".format(byte.toInt() and 0xff) }
    }

    private fun moveReplace(source: File, target: File) {
        try {
            Files.move(source.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE)
        } catch (_: Exception) {
            Files.move(source.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING)
        }
    }

    private fun writeLatestMarker(controller: ServerController, local: File) {
        val marker = File(controller.baseDir, "latest_backup.txt")
        val staged = File(controller.baseDir, ".latest_backup.txt.tmp")
        try {
            FileOutputStream(staged).use { output ->
                output.write((local.absolutePath + "\n").toByteArray(Charsets.UTF_8))
                output.fd.sync()
            }
            moveReplace(staged, marker)
        } finally {
            staged.delete()
        }
    }
}

/** Uploads the newest complete local snapshot only when Android reports working network connectivity. */
class DriveBackupWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        try {
            val context = applicationContext
            val prefs = context.getSharedPreferences(ServerController.PREFS, Context.MODE_PRIVATE)
            val treeUri = prefs.getString(ServerController.KEY_DRIVE_TREE, null)?.let(Uri::parse)
                ?: run {
                    saveSyncState("NOT_CONNECTED", "Choose a cloud folder on the Drive tab.")
                    return@withContext Result.success()
                }
            saveSyncState("SYNCING", "Checking the newest local snapshot.")
            val controller = ServerController(context)
            val backupRoot = controller.backupsDir
            val marker = File(controller.baseDir, "latest_backup.txt")
            val fromMarker = marker.takeIf { it.isFile }?.readText()?.trim()?.takeIf { it.isNotEmpty() }?.let(::File)
            val safeParent = backupRoot.canonicalFile
            val backup = fromMarker?.takeIf {
                runCatching {
                    it.isFile && it.name.startsWith("BlockHost-") && it.name.endsWith(".tar.gz") &&
                        it.canonicalFile.parentFile == safeParent
                }.getOrDefault(false)
            } ?: backupRoot.listFiles()
                ?.filter { it.isFile && it.name.startsWith("BlockHost-") && it.name.endsWith(".tar.gz") }
                ?.maxByOrNull { it.name }
                ?: run {
                    saveSyncState("WAITING_FOR_SNAPSHOT", "No local snapshot is available yet.")
                    return@withContext Result.success()
                }

            val sourceSignature = "${backup.name}:${backup.length()}:${backup.lastModified()}"
            // Avoid re-reading a multi-gigabyte archive when the latest local file is unchanged.
            if (prefs.getString(ServerController.KEY_LAST_UPLOADED_SOURCE, null) == sourceSignature) {
                saveSyncState("UP_TO_DATE", "Latest local snapshot was already confirmed in Drive.", backup.name)
                return@withContext Result.success()
            }
            val digest = sha256Local(backup)
            val uploadKey = "$sourceSignature:$digest"
            if (prefs.getString(ServerController.KEY_LAST_UPLOADED, null) == uploadKey) {
                saveSyncState("UP_TO_DATE", "Latest local snapshot is already confirmed in Drive.", backup.name)
                return@withContext Result.success()
            }

            val tree = DocumentFile.fromTreeUri(context, treeUri) ?: run {
                saveSyncState("PERMISSION_REQUIRED", "The selected cloud folder cannot be opened. Reconnect it.")
                return@withContext Result.retry()
            }
            val finalName = backup.name.removeSuffix(".tar.gz") + "-${digest.take(12)}.tar.gz"
            // If an identical completed backup already exists, don't upload it a second time.
            val existing = tree.findFile(finalName)
            if (existing != null && existing.isFile && runCatching { sha256(existing.uri, context) == digest }.getOrDefault(false)) {
                check(prefs.edit()
                    .putString(ServerController.KEY_LAST_UPLOADED, uploadKey)
                    .putString(ServerController.KEY_LAST_UPLOADED_SOURCE, sourceSignature)
                    .commit())
                saveSyncState("UP_TO_DATE", "Matching verified snapshot already exists in Drive.", backup.name, rememberSuccess = true)
                return@withContext Result.success()
            }

            // Temporary names are deliberately not recognized by restore/discovery code.
            // Unique temporary names let a retry proceed even if a previous interrupted
            // upload left an orphan that the Drive provider would not delete.
            val tempName = ".$finalName.${UUID.randomUUID()}.uploading"
            val temp = tree.createFile("application/octet-stream", tempName) ?: run {
                saveSyncState("RETRY_PENDING", "Could not create a temporary cloud file; check folder write permission.")
                return@withContext Result.retry()
            }
            try {
                context.contentResolver.openOutputStream(temp.uri, "wt").use { output ->
                    requireNotNull(output) { "Cloud backup target is not writable." }
                    backup.inputStream().use { input -> input.copyTo(output) }
                }
                // Read-back verification catches truncated, failed, or provider-mangled uploads.
                val uploadedDigest = sha256(temp.uri, context)
                if (uploadedDigest != digest) error("Cloud upload verification failed; the local snapshot was retained.")

                val existingAfterUpload = tree.findFile(finalName)
                if (existingAfterUpload != null) {
                    // Never replace an already completed snapshot just because names collide.
                    if (runCatching { sha256(existingAfterUpload.uri, context) == digest }.getOrDefault(false)) {
                        temp.delete()
                    } else {
                        error("A different cloud snapshot has the same name; it was left untouched.")
                    }
                } else if (!temp.renameTo(finalName)) {
                    error("Cloud provider could not finalize the verified upload. Retry sync; the temporary file is not restorable.")
                }
                check(prefs.edit()
                    .putString(ServerController.KEY_LAST_UPLOADED, uploadKey)
                    .putString(ServerController.KEY_LAST_UPLOADED_SOURCE, sourceSignature)
                    .commit()) {
                    "Cloud upload completed but sync state could not be saved. A later run will verify it again."
                }
                saveSyncState("UP_TO_DATE", "Uploaded and SHA-256 verified.", backup.name, rememberSuccess = true)

                // Keep the 20 newest completed snapshots; temporary upload files are never deleted by retention.
                tree.listFiles()
                    .filter { it.isFile && it.name.orEmpty().startsWith("BlockHost-") && it.name.orEmpty().endsWith(".tar.gz") }
                    .sortedByDescending { it.name.orEmpty() }
                    .drop(20)
                    .forEach { it.delete() }
            } catch (e: Exception) {
                temp.delete()
                throw e
            }
            Result.success()
        } catch (cancelled: CancellationException) {
            // WorkManager can cancel a superseded upload; do not swallow cancellation as retry.
            throw cancelled
        } catch (_: SecurityException) {
            saveSyncState("PERMISSION_REQUIRED", "Cloud folder permission is no longer available. Reconnect the folder.")
            Result.retry()
        } catch (error: Exception) {
            saveSyncState("RETRY_PENDING", error.message ?: "Cloud sync failed; local snapshot retained.")
            Result.retry()
        }
    }

    private fun saveSyncState(status: String, detail: String, backupName: String? = null, rememberSuccess: Boolean = false) {
        val prefs = applicationContext.getSharedPreferences(ServerController.PREFS, Context.MODE_PRIVATE)
        val editor = prefs.edit()
            .putString(ServerController.KEY_SYNC_STATUS, status)
            .putString(ServerController.KEY_SYNC_DETAIL, detail.take(300))
        if (backupName != null) editor.putString(ServerController.KEY_SYNC_LAST_BACKUP, backupName)
        if (rememberSuccess) editor.putLong(ServerController.KEY_SYNC_LAST_SUCCESS, System.currentTimeMillis())
        editor.commit()
    }

    private fun sha256Local(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        DigestInputStream(FileInputStream(file), digest).use { input ->
            val buffer = ByteArray(128 * 1024)
            while (input.read(buffer) != -1) { /* stream large world archives */ }
        }
        return digest.digest().joinToString("") { byte -> "%02x".format(byte.toInt() and 0xff) }
    }

    private fun sha256(uri: Uri, context: Context): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val source = context.contentResolver.openInputStream(uri)
            ?: error("Could not read cloud file for verification.")
        DigestInputStream(source, digest).use { input ->
            val buffer = ByteArray(128 * 1024)
            while (input.read(buffer) != -1) { /* stream content without buffering whole file */ }
        }
        return digest.digest().joinToString("") { byte -> "%02x".format(byte.toInt() and 0xff) }
    }
}
